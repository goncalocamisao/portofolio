using MySql.Data.MySqlClient;
using C__GestaoVendas.pt.com.Gvendas.VIEWS;

namespace C__GestaoVendas
{
    public partial class mainPanel : Form
    {
        public mainPanel()
        {
            InitializeComponent();
        }

        public string loggedInUsername;

        private void clienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Cliente clienteForm = new Cliente();
            clienteForm.Show();
        }

        private void fornecedorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Fornecedores fornecedoresForm = new Fornecedores();
            fornecedoresForm.Show();
        }

        private void produtosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Produtos produtosForm = new Produtos();
            produtosForm.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            txtAccount.Text = loggedInUsername;
        }

        private void funcion�riosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Funcionarios funcionariosForm = new Funcionarios();
            funcionariosForm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cliente clienteForm = new Cliente();
            clienteForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Fornecedores fornecedoresForm = new Fornecedores();
            fornecedoresForm.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Produtos produtosForm = new Produtos();
            produtosForm.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=11/12gon;database=dbvendas";
            string query = "SELECT acessos_sistema_vendas FROM tb_funcionario WHERE nome_funcionario=@username";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    connection.Open();
                    command.Parameters.AddWithValue("@username", txtAccount.Text);
                    object result = command.ExecuteScalar();
                    if (result != null && result != DBNull.Value && result.ToString() != "N�vel 1")
                    {
                        // User has permission to access the page
                        Funcionarios funcionariosForm = new Funcionarios();
                        funcionariosForm.Show();
                    }
                    else
                    {
                        // User does not have permission
                        MessageBox.Show("N�o tem permiss�es para aceder.");
                    }
                }
            }
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnEstadoEnc_Click(object sender, EventArgs e)
        {
            EstadoEncomendas estadoencomendasform = new EstadoEncomendas();
            estadoencomendasform.Show();
        }

        private void txtAccount_TextChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Cliente clienteForm = new Cliente();
            clienteForm.Show();
        }

        private void btnMaximize_Click(object sender, EventArgs e)
        {
            // Toggle the form's WindowState property and change the text of the button accordingly
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void mainPanel_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.ClientRectangle, Color.Black, 1, ButtonBorderStyle.Solid, Color.Black, 1, ButtonBorderStyle.Solid, Color.Black, 1, ButtonBorderStyle.Solid, Color.Black, 1, ButtonBorderStyle.Solid);
        }

        private bool dragging = false;
        private Point startPoint = new Point(0, 0);

        private void pnlHeader_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            startPoint = new Point(e.X, e.Y);
        }

        private void pnlHeader_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - startPoint.X, p.Y - startPoint.Y);
            }
        }

        private void pnlHeader_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }
    }
}