﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C__GestaoVendas.pt.com.Gvendas.VIEWS
{
    public partial class Produtos : Form
    {
        public Produtos()
        {
            InitializeComponent();
        }

        private void btnAdd_MouseHover(object sender, EventArgs e)
        {
            btnAdd.BackColor = Color.LightGreen;
        }

        private void btnAdd_MouseLeave(object sender, EventArgs e)
        {
            btnAdd.BackColor = Color.LightGray;
        }

        private void btnUpdate_MouseHover(object sender, EventArgs e)
        {
            btnUpdate.BackColor = Color.LightYellow;
        }

        private void btnUpdate_MouseLeave(object sender, EventArgs e)
        {
            btnUpdate.BackColor = Color.LightGray;
        }

        private void btnDelete_MouseHover(object sender, EventArgs e)
        {
            btnDelete.BackColor = Color.IndianRed;
        }

        private void btnDelete_MouseLeave(object sender, EventArgs e)
        {
            btnDelete.BackColor = Color.LightGray;
        }

        private void Produtos_Load(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=11/12gon;database=dbvendas";
            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM tb_produtos", connection);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dbvProdutos.DataSource = table;
            dbvProdutos.ReadOnly = true;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=11/12gon;database=dbvendas";
            string query = "INSERT INTO tb_produtos (estadoPrd, nome, fornecedor, quantidade_em_armazem, preco_unitario_do_produto, dataInicial, dataFim) VALUES (@value1, @value2, @value3, @value4, @value5, @value6, @value7)";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    connection.Open();
                    command.Parameters.AddWithValue("@value2", txt_nome.Text);
                    command.Parameters.AddWithValue("@value3", txt_fornecedor.Text);
                    command.Parameters.AddWithValue("@value1", txt_estadoPrd.Text);
                    command.Parameters.AddWithValue("@value4", txt_quantidade_em_armazem.Text);
                    command.Parameters.AddWithValue("@value5", txt_preco_unitario_do_produto.Text);
                    command.Parameters.AddWithValue("@value6", txt_dataInicial.Text);
                    command.Parameters.AddWithValue("@value7", txt_dataFim.Text);
                    try
                    {
                        int rowsAffected = command.ExecuteNonQuery();
                        MessageBox.Show("Produto " + txt_nome.Text + " foi adicionado com sucesso.");
                    }
                    catch (MySqlException ex)
                    {
                        MessageBox.Show("Erro ao adicionar produto.");
                    }
                }
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM tb_produtos", connection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dbvProdutos.DataSource = table;
                dbvProdutos.ReadOnly = true;
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string searchTerm = txtSearch.Text.ToLower(); // convert search term to lowercase
            if (searchTerm != "")
            {
                foreach (DataGridViewRow row in dbvProdutos.Rows)
                {
                    bool found = false;
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchTerm)) // convert cell value to lowercase
                        {
                            found = true;
                            break;
                        }
                    }
                    row.Selected = found;
                }
            }
            else
            {
                // Clear any previous selection
                dbvProdutos.ClearSelection();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=11/12gon;database=dbvendas";
            string query = "UPDATE tb_produtos SET estadoPrd = @value1, nome = @value2, fornecedor = @value3, quantidade_em_armazem = @value4, preco_unitario_do_produto = @value5, dataInicial = @value6, dataFim = @value7 WHERE id = @id";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    connection.Open();
                    command.Parameters.AddWithValue("@value2", txt_nome.Text);
                    command.Parameters.AddWithValue("@value3", txt_fornecedor.Text);
                    command.Parameters.AddWithValue("@value1", txt_estadoPrd.Text);
                    command.Parameters.AddWithValue("@value4", txt_quantidade_em_armazem.Text);
                    command.Parameters.AddWithValue("@value5", txt_preco_unitario_do_produto.Text);
                    command.Parameters.AddWithValue("@value6", txt_dataInicial.Text);
                    command.Parameters.AddWithValue("@value7", txt_dataFim.Text);
                    command.Parameters.AddWithValue("@id", txt_id.Text);
                    try
                    {
                        int rowsAffected = command.ExecuteNonQuery();
                        MessageBox.Show("Produto " + txt_nome.Text + " foi atualizado com sucesso.");
                    }
                    catch (MySqlException ex)
                    {
                        MessageBox.Show("Erro ao atualizar produto.");
                    }
                }

                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM tb_produtos", connection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dbvProdutos.DataSource = table;
                dbvProdutos.ReadOnly = true;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=11/12gon;database=dbvendas";
            string query = "DELETE FROM tb_produtos WHERE id = @id";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    connection.Open();
                    command.Parameters.AddWithValue("@id", txt_id.Text);
                    try
                    {
                        int rowsAffected = command.ExecuteNonQuery();
                        MessageBox.Show("Produto " + txt_nome.Text + " foi removido com sucesso.");
                    }
                    catch (MySqlException ex)
                    {
                        MessageBox.Show("Erro ao remover produto.");
                    }
                }
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM tb_produtos", connection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dbvProdutos.DataSource = table;
                dbvProdutos.ReadOnly = true;
            }
        }

        private void dbvProdutos_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvProdutos.Rows[e.RowIndex];
                txt_id.Text = row.Cells[0].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvProdutos.Rows[e.RowIndex];
                txt_nome.Text = row.Cells[2].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvProdutos.Rows[e.RowIndex];
                txt_fornecedor.Text = row.Cells[3].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvProdutos.Rows[e.RowIndex];
                txt_estadoPrd.Text = row.Cells[1].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvProdutos.Rows[e.RowIndex];
                txt_quantidade_em_armazem.Text = row.Cells[4].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvProdutos.Rows[e.RowIndex];
                txt_preco_unitario_do_produto.Text = row.Cells[5].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvProdutos.Rows[e.RowIndex];
                txt_dataInicial.Text = row.Cells[6].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvProdutos.Rows[e.RowIndex];
                txt_dataFim.Text = row.Cells[7].Value.ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            txt_id.Text = "";
            txt_nome.Text = "";
            txt_fornecedor.Text = "";
            txt_estadoPrd.SelectedIndex = -1;
            txt_quantidade_em_armazem.Text = "";
            txt_preco_unitario_do_produto.Text = "";
            txt_dataInicial.Text = "";
            txt_dataFim.Text = "";
            txtSearch.Text = "";
        }

        private void Produtos_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.ClientRectangle, Color.Black, 1, ButtonBorderStyle.Solid, Color.Black, 1, ButtonBorderStyle.Solid, Color.Black, 1, ButtonBorderStyle.Solid, Color.Black, 1, ButtonBorderStyle.Solid);
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMaximize_Click(object sender, EventArgs e)
        {
            // Toggle the form's WindowState property and change the text of the button accordingly
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private bool dragging = false;
        private Point startPoint = new Point(0, 0);

        private void pnlHeader_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            startPoint = new Point(e.X, e.Y);
        }

        private void pnlHeader_MouseLeave(object sender, EventArgs e)
        {
        }

        private void pnlHeader_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - startPoint.X, p.Y - startPoint.Y);
            }
        }

        private void pnlHeader_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;

        }
    }
}
