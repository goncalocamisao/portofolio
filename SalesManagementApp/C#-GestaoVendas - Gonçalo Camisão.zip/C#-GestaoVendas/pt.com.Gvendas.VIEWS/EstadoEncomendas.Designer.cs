﻿namespace C__GestaoVendas.pt.com.Gvendas.VIEWS
{
    partial class EstadoEncomendas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txt_data_encomenda = new TextBox();
            lblDateEnc = new Label();
            pnlTitle = new Panel();
            lblTitle = new Label();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            dbvCliente = new DataGridView();
            txtSearch = new TextBox();
            txt_estadoEnc = new ComboBox();
            txt_id = new TextBox();
            txt_cod_cliente = new TextBox();
            txt_num_nota_encomenda = new TextBox();
            txt_data_despacho = new TextBox();
            txt_data_entrega = new TextBox();
            txt_valor_total_encomenda = new TextBox();
            lblSearch = new Label();
            lblState = new Label();
            lblValue = new Label();
            lblDateEnt = new Label();
            lblDateDes = new Label();
            lblCode = new Label();
            lblNumber = new Label();
            lblId = new Label();
            pnlTitle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dbvCliente).BeginInit();
            SuspendLayout();
            // 
            // txt_data_encomenda
            // 
            txt_data_encomenda.Location = new Point(106, 211);
            txt_data_encomenda.Name = "txt_data_encomenda";
            txt_data_encomenda.Size = new Size(270, 27);
            txt_data_encomenda.TabIndex = 72;
            // 
            // lblDateEnc
            // 
            lblDateEnc.AutoSize = true;
            lblDateEnc.Location = new Point(16, 194);
            lblDateEnc.Name = "lblDateEnc";
            lblDateEnc.Size = new Size(90, 40);
            lblDateEnc.TabIndex = 71;
            lblDateEnc.Text = "Data da\r\nEncomenda:";
            // 
            // pnlTitle
            // 
            pnlTitle.BackColor = SystemColors.ControlDark;
            pnlTitle.Controls.Add(lblTitle);
            pnlTitle.Location = new Point(76, 7);
            pnlTitle.Name = "pnlTitle";
            pnlTitle.Size = new Size(236, 41);
            pnlTitle.TabIndex = 70;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            lblTitle.Location = new Point(5, 5);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(225, 31);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Estado Encomendas";
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(690, 404);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(94, 29);
            btnDelete.TabIndex = 69;
            btnDelete.Text = "Apagar";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.MouseLeave += btnDelete_MouseLeave;
            btnDelete.MouseHover += btnDelete_MouseHover;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(538, 404);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 29);
            btnUpdate.TabIndex = 68;
            btnUpdate.Text = "Atualizar";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.MouseLeave += btnUpdate_MouseLeave;
            btnUpdate.MouseHover += btnUpdate_MouseHover;
            // 
            // btnAdd
            // 
            btnAdd.Location = new Point(387, 404);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(94, 29);
            btnAdd.TabIndex = 67;
            btnAdd.Text = "Adicionar";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.MouseLeave += btnAdd_MouseLeave;
            btnAdd.MouseHover += btnAdd_MouseHover;
            // 
            // dbvCliente
            // 
            dbvCliente.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dbvCliente.Location = new Point(387, 52);
            dbvCliente.Name = "dbvCliente";
            dbvCliente.RowHeadersWidth = 51;
            dbvCliente.RowTemplate.Height = 29;
            dbvCliente.Size = new Size(397, 336);
            dbvCliente.TabIndex = 66;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(461, 17);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(323, 27);
            txtSearch.TabIndex = 65;
            // 
            // txt_estadoEnc
            // 
            txt_estadoEnc.DropDownStyle = ComboBoxStyle.DropDownList;
            txt_estadoEnc.FormattingEnabled = true;
            txt_estadoEnc.Items.AddRange(new object[] { "Em curso", "Em espera", "Completa", "Cancelada" });
            txt_estadoEnc.Location = new Point(106, 124);
            txt_estadoEnc.Name = "txt_estadoEnc";
            txt_estadoEnc.Size = new Size(270, 28);
            txt_estadoEnc.TabIndex = 64;
            // 
            // txt_id
            // 
            txt_id.Location = new Point(106, 54);
            txt_id.Name = "txt_id";
            txt_id.ReadOnly = true;
            txt_id.Size = new Size(270, 27);
            txt_id.TabIndex = 63;
            // 
            // txt_cod_cliente
            // 
            txt_cod_cliente.Location = new Point(106, 89);
            txt_cod_cliente.Name = "txt_cod_cliente";
            txt_cod_cliente.Size = new Size(270, 27);
            txt_cod_cliente.TabIndex = 62;
            // 
            // txt_num_nota_encomenda
            // 
            txt_num_nota_encomenda.Location = new Point(106, 159);
            txt_num_nota_encomenda.Name = "txt_num_nota_encomenda";
            txt_num_nota_encomenda.Size = new Size(270, 27);
            txt_num_nota_encomenda.TabIndex = 61;
            // 
            // txt_data_despacho
            // 
            txt_data_despacho.Location = new Point(106, 265);
            txt_data_despacho.Name = "txt_data_despacho";
            txt_data_despacho.Size = new Size(270, 27);
            txt_data_despacho.TabIndex = 60;
            // 
            // txt_data_entrega
            // 
            txt_data_entrega.Location = new Point(106, 320);
            txt_data_entrega.Name = "txt_data_entrega";
            txt_data_entrega.Size = new Size(270, 27);
            txt_data_entrega.TabIndex = 59;
            // 
            // txt_valor_total_encomenda
            // 
            txt_valor_total_encomenda.Location = new Point(106, 359);
            txt_valor_total_encomenda.Name = "txt_valor_total_encomenda";
            txt_valor_total_encomenda.Size = new Size(270, 27);
            txt_valor_total_encomenda.TabIndex = 58;
            // 
            // lblSearch
            // 
            lblSearch.AutoSize = true;
            lblSearch.Location = new Point(382, 17);
            lblSearch.Name = "lblSearch";
            lblSearch.Size = new Size(73, 20);
            lblSearch.TabIndex = 57;
            lblSearch.Text = "Pesquisar:";
            // 
            // lblState
            // 
            lblState.AutoSize = true;
            lblState.Location = new Point(16, 124);
            lblState.Name = "lblState";
            lblState.Size = new Size(57, 20);
            lblState.TabIndex = 56;
            lblState.Text = "Estado:";
            // 
            // lblValue
            // 
            lblValue.AutoSize = true;
            lblValue.Location = new Point(16, 359);
            lblValue.Name = "lblValue";
            lblValue.Size = new Size(83, 20);
            lblValue.TabIndex = 55;
            lblValue.Text = "Valor Total:";
            // 
            // lblDateEnt
            // 
            lblDateEnt.AutoSize = true;
            lblDateEnt.Location = new Point(16, 304);
            lblDateEnt.Name = "lblDateEnt";
            lblDateEnt.Size = new Size(63, 40);
            lblDateEnt.TabIndex = 54;
            lblDateEnt.Text = "Data da\r\nEntrega:";
            // 
            // lblDateDes
            // 
            lblDateDes.AutoSize = true;
            lblDateDes.Location = new Point(16, 249);
            lblDateDes.Name = "lblDateDes";
            lblDateDes.Size = new Size(78, 40);
            lblDateDes.TabIndex = 53;
            lblDateDes.Text = "Data do\r\nDespacho:";
            // 
            // lblCode
            // 
            lblCode.AutoSize = true;
            lblCode.Location = new Point(16, 89);
            lblCode.Name = "lblCode";
            lblCode.Size = new Size(61, 20);
            lblCode.TabIndex = 52;
            lblCode.Text = "Código:";
            // 
            // lblNumber
            // 
            lblNumber.AutoSize = true;
            lblNumber.Location = new Point(16, 159);
            lblNumber.Name = "lblNumber";
            lblNumber.Size = new Size(66, 20);
            lblNumber.TabIndex = 51;
            lblNumber.Text = "Numero:";
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.Location = new Point(16, 54);
            lblId.Name = "lblId";
            lblId.Size = new Size(25, 20);
            lblId.TabIndex = 50;
            lblId.Text = "Id:";
            // 
            // EstadoEncomendas
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txt_data_encomenda);
            Controls.Add(lblDateEnc);
            Controls.Add(pnlTitle);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(dbvCliente);
            Controls.Add(txtSearch);
            Controls.Add(txt_estadoEnc);
            Controls.Add(txt_id);
            Controls.Add(txt_cod_cliente);
            Controls.Add(txt_num_nota_encomenda);
            Controls.Add(txt_data_despacho);
            Controls.Add(txt_data_entrega);
            Controls.Add(txt_valor_total_encomenda);
            Controls.Add(lblSearch);
            Controls.Add(lblState);
            Controls.Add(lblValue);
            Controls.Add(lblDateEnt);
            Controls.Add(lblDateDes);
            Controls.Add(lblCode);
            Controls.Add(lblNumber);
            Controls.Add(lblId);
            Name = "EstadoEncomendas";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Estado Encomendas";
            pnlTitle.ResumeLayout(false);
            pnlTitle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dbvCliente).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txt_data_encomenda;
        private Label lblDateEnc;
        private Panel pnlTitle;
        private Label lblTitle;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private DataGridView dbvCliente;
        private TextBox txtSearch;
        private ComboBox txt_estadoEnc;
        private TextBox txt_id;
        private TextBox txt_cod_cliente;
        private TextBox txt_num_nota_encomenda;
        private TextBox txt_data_despacho;
        private TextBox txt_data_entrega;
        private TextBox txt_valor_total_encomenda;
        private Label lblSearch;
        private Label lblState;
        private Label lblValue;
        private Label lblDateEnt;
        private Label lblDateDes;
        private Label lblCode;
        private Label lblNumber;
        private Label lblId;
    }
}