﻿namespace C__GestaoVendas.pt.com.Gvendas.VIEWS
{
    partial class Fornecedores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Fornecedores));
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            dbvFornecedores = new DataGridView();
            txtSearch = new TextBox();
            txt_estadoForn = new ComboBox();
            txt_id = new TextBox();
            txt_cod_fornecedor = new TextBox();
            txt_nome_fornecedor = new TextBox();
            txt_email = new TextBox();
            txt_telefone = new TextBox();
            txt_dataInicial = new TextBox();
            txt_morada = new TextBox();
            lblSearch = new Label();
            lblName = new Label();
            lblDate = new Label();
            lblAddress = new Label();
            lblPhoneNumber = new Label();
            lblEmail = new Label();
            lblCode = new Label();
            lblState = new Label();
            lblId = new Label();
            button1 = new Button();
            pnlHeader = new Panel();
            label1 = new Label();
            btnMinimize = new Button();
            btnMaximize = new Button();
            btnClose = new Button();
            ((System.ComponentModel.ISupportInitialize)dbvFornecedores).BeginInit();
            pnlHeader.SuspendLayout();
            SuspendLayout();
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.FromArgb(241, 246, 249);
            btnDelete.Cursor = Cursors.Hand;
            btnDelete.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.ForeColor = Color.FromArgb(33, 42, 62);
            btnDelete.Location = new Point(690, 451);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(94, 29);
            btnDelete.TabIndex = 46;
            btnDelete.Text = "Apagar";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            btnDelete.MouseLeave += btnDelete_MouseLeave;
            btnDelete.MouseHover += btnDelete_MouseHover;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(241, 246, 249);
            btnUpdate.Cursor = Cursors.Hand;
            btnUpdate.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.ForeColor = Color.FromArgb(33, 42, 62);
            btnUpdate.Location = new Point(538, 451);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 29);
            btnUpdate.TabIndex = 45;
            btnUpdate.Text = "Atualizar";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            btnUpdate.MouseLeave += btnUpdate_MouseLeave;
            btnUpdate.MouseHover += btnUpdate_MouseHover;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.FromArgb(241, 246, 249);
            btnAdd.Cursor = Cursors.Hand;
            btnAdd.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.ForeColor = Color.FromArgb(33, 42, 62);
            btnAdd.Location = new Point(387, 451);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(94, 29);
            btnAdd.TabIndex = 44;
            btnAdd.Text = "Adicionar";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            btnAdd.MouseLeave += btnAdd_MouseLeave;
            btnAdd.MouseHover += btnAdd_MouseHover;
            // 
            // dbvFornecedores
            // 
            dbvFornecedores.BackgroundColor = Color.FromArgb(155, 164, 181);
            dbvFornecedores.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dbvFornecedores.GridColor = Color.FromArgb(33, 42, 62);
            dbvFornecedores.Location = new Point(387, 99);
            dbvFornecedores.Name = "dbvFornecedores";
            dbvFornecedores.RowHeadersWidth = 51;
            dbvFornecedores.RowTemplate.Height = 29;
            dbvFornecedores.Size = new Size(397, 336);
            dbvFornecedores.TabIndex = 43;
            dbvFornecedores.CellClick += dbvFornecedores_CellClick;
            dbvFornecedores.CellContentClick += dbvFornecedores_CellContentClick;
            // 
            // txtSearch
            // 
            txtSearch.BackColor = Color.FromArgb(241, 246, 249);
            txtSearch.ForeColor = Color.FromArgb(33, 42, 62);
            txtSearch.Location = new Point(461, 64);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(323, 27);
            txtSearch.TabIndex = 42;
            txtSearch.TextChanged += txtSearch_TextChanged;
            // 
            // txt_estadoForn
            // 
            txt_estadoForn.BackColor = Color.FromArgb(241, 246, 249);
            txt_estadoForn.DropDownStyle = ComboBoxStyle.DropDownList;
            txt_estadoForn.ForeColor = Color.FromArgb(33, 42, 62);
            txt_estadoForn.FormattingEnabled = true;
            txt_estadoForn.Items.AddRange(new object[] { "Ativo", "Inativo" });
            txt_estadoForn.Location = new Point(106, 204);
            txt_estadoForn.Name = "txt_estadoForn";
            txt_estadoForn.Size = new Size(270, 28);
            txt_estadoForn.TabIndex = 41;
            // 
            // txt_id
            // 
            txt_id.BackColor = Color.FromArgb(241, 246, 249);
            txt_id.ForeColor = Color.FromArgb(33, 42, 62);
            txt_id.Location = new Point(106, 99);
            txt_id.Name = "txt_id";
            txt_id.ReadOnly = true;
            txt_id.Size = new Size(270, 27);
            txt_id.TabIndex = 40;
            // 
            // txt_cod_fornecedor
            // 
            txt_cod_fornecedor.BackColor = Color.FromArgb(241, 246, 249);
            txt_cod_fornecedor.ForeColor = Color.FromArgb(33, 42, 62);
            txt_cod_fornecedor.Location = new Point(106, 134);
            txt_cod_fornecedor.Name = "txt_cod_fornecedor";
            txt_cod_fornecedor.ReadOnly = true;
            txt_cod_fornecedor.Size = new Size(270, 27);
            txt_cod_fornecedor.TabIndex = 39;
            // 
            // txt_nome_fornecedor
            // 
            txt_nome_fornecedor.BackColor = Color.FromArgb(241, 246, 249);
            txt_nome_fornecedor.ForeColor = Color.FromArgb(33, 42, 62);
            txt_nome_fornecedor.Location = new Point(106, 169);
            txt_nome_fornecedor.Name = "txt_nome_fornecedor";
            txt_nome_fornecedor.Size = new Size(270, 27);
            txt_nome_fornecedor.TabIndex = 38;
            // 
            // txt_email
            // 
            txt_email.BackColor = Color.FromArgb(241, 246, 249);
            txt_email.ForeColor = Color.FromArgb(33, 42, 62);
            txt_email.Location = new Point(106, 239);
            txt_email.Name = "txt_email";
            txt_email.Size = new Size(270, 27);
            txt_email.TabIndex = 37;
            // 
            // txt_telefone
            // 
            txt_telefone.BackColor = Color.FromArgb(241, 246, 249);
            txt_telefone.ForeColor = Color.FromArgb(33, 42, 62);
            txt_telefone.Location = new Point(106, 274);
            txt_telefone.Name = "txt_telefone";
            txt_telefone.Size = new Size(270, 27);
            txt_telefone.TabIndex = 36;
            // 
            // txt_dataInicial
            // 
            txt_dataInicial.BackColor = Color.FromArgb(241, 246, 249);
            txt_dataInicial.ForeColor = Color.FromArgb(33, 42, 62);
            txt_dataInicial.Location = new Point(106, 408);
            txt_dataInicial.Name = "txt_dataInicial";
            txt_dataInicial.Size = new Size(270, 27);
            txt_dataInicial.TabIndex = 35;
            // 
            // txt_morada
            // 
            txt_morada.BackColor = Color.FromArgb(241, 246, 249);
            txt_morada.ForeColor = Color.FromArgb(33, 42, 62);
            txt_morada.Location = new Point(106, 309);
            txt_morada.Multiline = true;
            txt_morada.Name = "txt_morada";
            txt_morada.Size = new Size(270, 81);
            txt_morada.TabIndex = 34;
            // 
            // lblSearch
            // 
            lblSearch.AutoSize = true;
            lblSearch.ForeColor = Color.FromArgb(33, 42, 62);
            lblSearch.Location = new Point(382, 64);
            lblSearch.Name = "lblSearch";
            lblSearch.Size = new Size(73, 20);
            lblSearch.TabIndex = 33;
            lblSearch.Text = "Pesquisar:";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.ForeColor = Color.FromArgb(33, 42, 62);
            lblName.Location = new Point(16, 169);
            lblName.Name = "lblName";
            lblName.Size = new Size(53, 20);
            lblName.TabIndex = 32;
            lblName.Text = "Nome:";
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.ForeColor = Color.FromArgb(33, 42, 62);
            lblDate.Location = new Point(16, 408);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(84, 20);
            lblDate.TabIndex = 31;
            lblDate.Text = "Data Início:";
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.ForeColor = Color.FromArgb(33, 42, 62);
            lblAddress.Location = new Point(16, 309);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(64, 20);
            lblAddress.TabIndex = 30;
            lblAddress.Text = "Morada:";
            // 
            // lblPhoneNumber
            // 
            lblPhoneNumber.AutoSize = true;
            lblPhoneNumber.ForeColor = Color.FromArgb(33, 42, 62);
            lblPhoneNumber.Location = new Point(16, 274);
            lblPhoneNumber.Name = "lblPhoneNumber";
            lblPhoneNumber.Size = new Size(69, 20);
            lblPhoneNumber.TabIndex = 29;
            lblPhoneNumber.Text = "Telefone:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.ForeColor = Color.FromArgb(33, 42, 62);
            lblEmail.Location = new Point(16, 239);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(49, 20);
            lblEmail.TabIndex = 28;
            lblEmail.Text = "Email:";
            // 
            // lblCode
            // 
            lblCode.AutoSize = true;
            lblCode.ForeColor = Color.FromArgb(33, 42, 62);
            lblCode.Location = new Point(16, 134);
            lblCode.Name = "lblCode";
            lblCode.Size = new Size(61, 20);
            lblCode.TabIndex = 27;
            lblCode.Text = "Código:";
            // 
            // lblState
            // 
            lblState.AutoSize = true;
            lblState.ForeColor = Color.FromArgb(33, 42, 62);
            lblState.Location = new Point(16, 204);
            lblState.Name = "lblState";
            lblState.Size = new Size(57, 20);
            lblState.TabIndex = 26;
            lblState.Text = "Estado:";
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.ForeColor = Color.FromArgb(33, 42, 62);
            lblId.Location = new Point(16, 99);
            lblId.Name = "lblId";
            lblId.Size = new Size(25, 20);
            lblId.TabIndex = 25;
            lblId.Text = "Id:";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(241, 246, 249);
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
            button1.ForeColor = Color.FromArgb(33, 42, 62);
            button1.Location = new Point(3, 464);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(46, 23);
            button1.TabIndex = 48;
            button1.Text = "Reset";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.FromArgb(33, 42, 62);
            pnlHeader.Controls.Add(label1);
            pnlHeader.Controls.Add(btnMinimize);
            pnlHeader.Controls.Add(btnMaximize);
            pnlHeader.Controls.Add(btnClose);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(800, 40);
            pnlHeader.TabIndex = 49;
            pnlHeader.MouseDown += pnlHeader_MouseDown;
            pnlHeader.MouseMove += pnlHeader_MouseMove;
            pnlHeader.MouseUp += pnlHeader_MouseUp;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(241, 246, 249);
            label1.Location = new Point(9, 6);
            label1.Name = "label1";
            label1.Size = new Size(258, 28);
            label1.TabIndex = 20;
            label1.Text = "Formulário de Fornecedores";
            // 
            // btnMinimize
            // 
            btnMinimize.BackColor = Color.FromArgb(33, 42, 62);
            btnMinimize.Cursor = Cursors.Hand;
            btnMinimize.FlatAppearance.BorderSize = 0;
            btnMinimize.FlatStyle = FlatStyle.Flat;
            btnMinimize.Image = (Image)resources.GetObject("btnMinimize.Image");
            btnMinimize.Location = new Point(693, 6);
            btnMinimize.Name = "btnMinimize";
            btnMinimize.Size = new Size(29, 29);
            btnMinimize.TabIndex = 19;
            btnMinimize.UseVisualStyleBackColor = false;
            btnMinimize.Click += btnMinimize_Click;
            // 
            // btnMaximize
            // 
            btnMaximize.BackColor = Color.FromArgb(33, 42, 62);
            btnMaximize.Cursor = Cursors.Hand;
            btnMaximize.FlatAppearance.BorderSize = 0;
            btnMaximize.FlatStyle = FlatStyle.Flat;
            btnMaximize.Image = (Image)resources.GetObject("btnMaximize.Image");
            btnMaximize.Location = new Point(728, 6);
            btnMaximize.Name = "btnMaximize";
            btnMaximize.Size = new Size(29, 29);
            btnMaximize.TabIndex = 18;
            btnMaximize.UseVisualStyleBackColor = false;
            btnMaximize.Click += btnMaximize_Click;
            // 
            // btnClose
            // 
            btnClose.BackColor = Color.FromArgb(33, 42, 62);
            btnClose.Cursor = Cursors.Hand;
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.FlatStyle = FlatStyle.Flat;
            btnClose.Image = (Image)resources.GetObject("btnClose.Image");
            btnClose.Location = new Point(765, 6);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(29, 29);
            btnClose.TabIndex = 17;
            btnClose.UseVisualStyleBackColor = false;
            btnClose.Click += btnClose_Click;
            // 
            // Fornecedores
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(241, 246, 249);
            ClientSize = new Size(800, 490);
            Controls.Add(pnlHeader);
            Controls.Add(button1);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(dbvFornecedores);
            Controls.Add(txtSearch);
            Controls.Add(txt_estadoForn);
            Controls.Add(txt_id);
            Controls.Add(txt_cod_fornecedor);
            Controls.Add(txt_nome_fornecedor);
            Controls.Add(txt_email);
            Controls.Add(txt_telefone);
            Controls.Add(txt_dataInicial);
            Controls.Add(txt_morada);
            Controls.Add(lblSearch);
            Controls.Add(lblName);
            Controls.Add(lblDate);
            Controls.Add(lblAddress);
            Controls.Add(lblPhoneNumber);
            Controls.Add(lblEmail);
            Controls.Add(lblCode);
            Controls.Add(lblState);
            Controls.Add(lblId);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Fornecedores";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Formulário de Fornecedores";
            Load += Fornecedores_Load;
            Paint += Fornecedores_Paint;
            ((System.ComponentModel.ISupportInitialize)dbvFornecedores).EndInit();
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private DataGridView dbvFornecedores;
        private TextBox txtSearch;
        private ComboBox txt_estadoForn;
        private TextBox txt_id;
        private TextBox txt_cod_fornecedor;
        private TextBox txt_nome_fornecedor;
        private TextBox txt_email;
        private TextBox txt_telefone;
        private TextBox txt_dataInicial;
        private TextBox txt_morada;
        private Label lblSearch;
        private Label lblName;
        private Label lblDate;
        private Label lblAddress;
        private Label lblPhoneNumber;
        private Label lblEmail;
        private Label lblCode;
        private Label lblState;
        private Label lblId;
        private Button button1;
        private Panel pnlHeader;
        private Label label1;
        private Button btnMinimize;
        private Button btnMaximize;
        private Button btnClose;
    }
}