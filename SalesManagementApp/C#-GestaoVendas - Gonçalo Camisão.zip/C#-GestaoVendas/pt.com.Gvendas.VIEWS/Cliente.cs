﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace C__GestaoVendas.pt.com.Gvendas.VIEWS
{
    public partial class Cliente : Form
    {
        public Cliente()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bindingSource1_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void Cliente_Load(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=11/12gon;database=dbvendas";
            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM tb_clientes", connection);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dbvCliente.DataSource = table;
            dbvCliente.ReadOnly = true;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void lblSearch_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_MouseHover(object sender, EventArgs e)
        {
            btnAdd.BackColor = Color.LightGreen;
        }

        private void btnAdd_MouseLeave(object sender, EventArgs e)
        {
            btnAdd.BackColor = Color.LightGray;
        }

        private void btnUpdate_MouseHover(object sender, EventArgs e)
        {
            btnUpdate.BackColor = Color.LightYellow;
        }

        private void btnUpdate_MouseLeave(object sender, EventArgs e)
        {
            btnUpdate.BackColor = Color.LightGray;
        }

        private void btnDelete_MouseHover(object sender, EventArgs e)
        {
            btnDelete.BackColor = Color.IndianRed;
        }

        private void btnDelete_MouseLeave(object sender, EventArgs e)
        {
            btnDelete.BackColor = Color.LightGray;
        }

        private void dbvCliente_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string searchTerm = txtSearch.Text.ToLower(); // convert search term to lowercase
            if (searchTerm != "")
            {
                foreach (DataGridViewRow row in dbvCliente.Rows)
                {
                    bool found = false;
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchTerm)) // convert cell value to lowercase
                        {
                            found = true;
                            break;
                        }
                    }
                    row.Selected = found;
                }
            }
            else
            {
                // Clear any previous selection
                dbvCliente.ClearSelection();
            }
        }

        private void dbvCliente_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvCliente.Rows[e.RowIndex];
                txt_id.Text = row.Cells[0].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvCliente.Rows[e.RowIndex];
                txt_cod_cliente.Text = row.Cells[3].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvCliente.Rows[e.RowIndex];
                txt_nome_cliente.Text = row.Cells[2].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvCliente.Rows[e.RowIndex];
                txt_estadoCli.Text = row.Cells[1].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvCliente.Rows[e.RowIndex];
                txt_email.Text = row.Cells[4].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvCliente.Rows[e.RowIndex];
                txt_telefone.Text = row.Cells[5].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvCliente.Rows[e.RowIndex];
                txt_morada.Text = row.Cells[6].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvCliente.Rows[e.RowIndex];
                txt_dataInicio.Text = row.Cells[7].Value.ToString();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=11/12gon;database=dbvendas";
            string query = "UPDATE tb_clientes SET estadoCli = @value1, nome_cliente = @value2, email = @value3, telefone = @value4, morada = @value5, dataInicio = @value6 WHERE id = @id";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    connection.Open();
                    command.Parameters.AddWithValue("@value2", txt_nome_cliente.Text);
                    command.Parameters.AddWithValue("@value1", txt_estadoCli.Text);
                    command.Parameters.AddWithValue("@value3", txt_email.Text);
                    command.Parameters.AddWithValue("@value4", txt_telefone.Text);
                    command.Parameters.AddWithValue("@value5", txt_morada.Text);
                    command.Parameters.AddWithValue("@value6", txt_dataInicio.Text);
                    command.Parameters.AddWithValue("@id", txt_id.Text);
                    try
                    {
                        int rowsAffected = command.ExecuteNonQuery();
                        MessageBox.Show("Cliente " + txt_nome_cliente.Text + " foi atualizado/a com sucesso.");
                    }
                    catch (MySqlException ex)
                    {
                        MessageBox.Show("Erro ao atualizar cliente.");
                    }
                }

                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM tb_clientes", connection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dbvCliente.DataSource = table;
                dbvCliente.ReadOnly = true;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=11/12gon;database=dbvendas";
            string query = "DELETE FROM tb_clientes WHERE id = @id";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    connection.Open();
                    command.Parameters.AddWithValue("@id", txt_id.Text);
                    try
                    {
                        int rowsAffected = command.ExecuteNonQuery();
                        MessageBox.Show("Cliente " + txt_nome_cliente.Text + " foi removido/a com sucesso.");
                    }
                    catch (MySqlException ex)
                    {
                        MessageBox.Show("Erro ao remover cliente.");
                    }
                }
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM tb_clientes", connection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dbvCliente.DataSource = table;
                dbvCliente.ReadOnly = true;
            }

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=11/12gon;database=dbvendas";
            string query = "INSERT INTO tb_clientes (estadoCli, nome_cliente, email, telefone, morada, dataInicio) VALUES (@value1, @value2, @value3, @value4, @value5, @value6)";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    connection.Open();
                    command.Parameters.AddWithValue("@value2", txt_nome_cliente.Text);
                    command.Parameters.AddWithValue("@value1", txt_estadoCli.Text);
                    command.Parameters.AddWithValue("@value3", txt_email.Text);
                    command.Parameters.AddWithValue("@value4", txt_telefone.Text);
                    command.Parameters.AddWithValue("@value5", txt_morada.Text);
                    command.Parameters.AddWithValue("@value6", txt_dataInicio.Text);
                    try
                    {
                        int rowsAffected = command.ExecuteNonQuery();
                        MessageBox.Show("Cliente " + txt_nome_cliente.Text + " foi adicionado/a com sucesso.");
                    }
                    catch (MySqlException ex)
                    {
                        MessageBox.Show("Erro ao adicionar cliente.");
                    }
                }
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM tb_clientes", connection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dbvCliente.DataSource = table;
                dbvCliente.ReadOnly = true;
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            txt_id.Text = "";
            txt_cod_cliente.Text = "";
            txt_nome_cliente.Text = "";
            txt_estadoCli.SelectedIndex = -1;
            txt_email.Text = "";
            txt_telefone.Text = "";
            txt_morada.Text = "";
            txt_dataInicio.Text = "";
            txtSearch.Text = "";
            // Repeat the above line for each TextBox control you want to reset.
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnMaximize_Click(object sender, EventArgs e)
        {
            // Toggle the form's WindowState property and change the text of the button accordingly
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Cliente_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.ClientRectangle, Color.Black, 1, ButtonBorderStyle.Solid, Color.Black, 1, ButtonBorderStyle.Solid, Color.Black, 1, ButtonBorderStyle.Solid, Color.Black, 1, ButtonBorderStyle.Solid);

        }

        private bool dragging = false;
        private Point startPoint = new Point(0, 0);

        private void pnlHeader_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            startPoint = new Point(e.X, e.Y);
        }

        private void pnlHeader_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - startPoint.X, p.Y - startPoint.Y);
            }
        }

        private void pnlHeader_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }
    }
}
