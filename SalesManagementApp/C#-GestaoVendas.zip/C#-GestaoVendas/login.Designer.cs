﻿namespace C__GestaoVendas
{
    partial class login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(login));
            lbl_Funcionario = new Label();
            lbl_password = new Label();
            txtPassword = new TextBox();
            btnLogin = new Button();
            cmbFuncionario = new ComboBox();
            btnRefresh = new Button();
            pnlHeader = new Panel();
            lblTitle = new Label();
            btnMinimize = new Button();
            btnMaximize = new Button();
            btnClose = new Button();
            pnlHeader.SuspendLayout();
            SuspendLayout();
            // 
            // lbl_Funcionario
            // 
            lbl_Funcionario.AutoSize = true;
            lbl_Funcionario.ForeColor = Color.FromArgb(33, 42, 62);
            lbl_Funcionario.Location = new Point(54, 96);
            lbl_Funcionario.Name = "lbl_Funcionario";
            lbl_Funcionario.Size = new Size(89, 20);
            lbl_Funcionario.TabIndex = 0;
            lbl_Funcionario.Text = "Funcionário:";
            // 
            // lbl_password
            // 
            lbl_password.AutoSize = true;
            lbl_password.ForeColor = Color.FromArgb(33, 42, 62);
            lbl_password.Location = new Point(54, 129);
            lbl_password.Name = "lbl_password";
            lbl_password.Size = new Size(73, 20);
            lbl_password.TabIndex = 1;
            lbl_password.Text = "Password:";
            // 
            // txtPassword
            // 
            txtPassword.BackColor = Color.FromArgb(241, 246, 249);
            txtPassword.ForeColor = Color.FromArgb(33, 42, 62);
            txtPassword.Location = new Point(165, 126);
            txtPassword.Name = "txtPassword";
            txtPassword.PasswordChar = '*';
            txtPassword.Size = new Size(151, 27);
            txtPassword.TabIndex = 3;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.FromArgb(241, 246, 249);
            btnLogin.Cursor = Cursors.Hand;
            btnLogin.FlatAppearance.BorderSize = 0;
            btnLogin.FlatStyle = FlatStyle.Flat;
            btnLogin.ForeColor = Color.FromArgb(33, 42, 62);
            btnLogin.Image = (Image)resources.GetObject("btnLogin.Image");
            btnLogin.ImageAlign = ContentAlignment.MiddleRight;
            btnLogin.Location = new Point(182, 165);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(94, 32);
            btnLogin.TabIndex = 4;
            btnLogin.Text = "Entar";
            btnLogin.TextAlign = ContentAlignment.MiddleLeft;
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // cmbFuncionario
            // 
            cmbFuncionario.BackColor = Color.FromArgb(241, 246, 249);
            cmbFuncionario.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbFuncionario.ForeColor = Color.FromArgb(33, 42, 62);
            cmbFuncionario.FormattingEnabled = true;
            cmbFuncionario.Location = new Point(165, 93);
            cmbFuncionario.Name = "cmbFuncionario";
            cmbFuncionario.Size = new Size(151, 28);
            cmbFuncionario.TabIndex = 6;
            cmbFuncionario.SelectedIndexChanged += cmbFuncionario_SelectedIndexChanged;
            // 
            // btnRefresh
            // 
            btnRefresh.Cursor = Cursors.Hand;
            btnRefresh.FlatAppearance.BorderSize = 0;
            btnRefresh.FlatStyle = FlatStyle.Flat;
            btnRefresh.Image = (Image)resources.GetObject("btnRefresh.Image");
            btnRefresh.Location = new Point(2, 42);
            btnRefresh.Name = "btnRefresh";
            btnRefresh.Size = new Size(30, 29);
            btnRefresh.TabIndex = 7;
            btnRefresh.UseVisualStyleBackColor = true;
            btnRefresh.Click += button1_Click;
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.FromArgb(33, 42, 62);
            pnlHeader.Controls.Add(lblTitle);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(382, 40);
            pnlHeader.TabIndex = 8;
            pnlHeader.MouseDown += pnlHeader_MouseDown;
            pnlHeader.MouseMove += pnlHeader_MouseMove;
            pnlHeader.MouseUp += pnlHeader_MouseUp;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblTitle.ForeColor = Color.FromArgb(241, 246, 249);
            lblTitle.Location = new Point(9, 6);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(61, 28);
            lblTitle.TabIndex = 18;
            lblTitle.Text = "Login";
            // 
            // btnMinimize
            // 
            btnMinimize.BackColor = Color.FromArgb(33, 42, 62);
            btnMinimize.Cursor = Cursors.Hand;
            btnMinimize.FlatAppearance.BorderSize = 0;
            btnMinimize.FlatStyle = FlatStyle.Flat;
            btnMinimize.Image = (Image)resources.GetObject("btnMinimize.Image");
            btnMinimize.Location = new Point(275, 6);
            btnMinimize.Name = "btnMinimize";
            btnMinimize.Size = new Size(29, 29);
            btnMinimize.TabIndex = 19;
            btnMinimize.UseVisualStyleBackColor = false;
            btnMinimize.Click += btnMinimize_Click;
            // 
            // btnMaximize
            // 
            btnMaximize.BackColor = Color.FromArgb(33, 42, 62);
            btnMaximize.Cursor = Cursors.Hand;
            btnMaximize.FlatAppearance.BorderSize = 0;
            btnMaximize.FlatStyle = FlatStyle.Flat;
            btnMaximize.Image = (Image)resources.GetObject("btnMaximize.Image");
            btnMaximize.Location = new Point(310, 6);
            btnMaximize.Name = "btnMaximize";
            btnMaximize.Size = new Size(29, 29);
            btnMaximize.TabIndex = 18;
            btnMaximize.UseVisualStyleBackColor = false;
            btnMaximize.Click += btnMaximize_Click;
            // 
            // btnClose
            // 
            btnClose.BackColor = Color.FromArgb(33, 42, 62);
            btnClose.Cursor = Cursors.Hand;
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.FlatStyle = FlatStyle.Flat;
            btnClose.Image = (Image)resources.GetObject("btnClose.Image");
            btnClose.Location = new Point(347, 6);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(29, 29);
            btnClose.TabIndex = 17;
            btnClose.UseVisualStyleBackColor = false;
            btnClose.Click += btnClose_Click;
            // 
            // login
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(241, 246, 249);
            ClientSize = new Size(382, 236);
            Controls.Add(btnMinimize);
            Controls.Add(btnMaximize);
            Controls.Add(btnClose);
            Controls.Add(pnlHeader);
            Controls.Add(btnRefresh);
            Controls.Add(cmbFuncionario);
            Controls.Add(btnLogin);
            Controls.Add(txtPassword);
            Controls.Add(lbl_password);
            Controls.Add(lbl_Funcionario);
            FormBorderStyle = FormBorderStyle.None;
            Name = "login";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "login";
            Load += login_Load;
            Paint += login_Paint;
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbl_Funcionario;
        private Label lbl_password;
        private TextBox txtPassword;
        private Button btnLogin;
        private ComboBox cmbFuncionario;
        private Button btnRefresh;
        private Panel pnlHeader;
        private Button btnMinimize;
        private Button btnMaximize;
        private Button btnClose;
        private Label lblTitle;
    }
}