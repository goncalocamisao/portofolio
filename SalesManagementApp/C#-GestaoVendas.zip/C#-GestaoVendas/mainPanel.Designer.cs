﻿namespace C__GestaoVendas
{
    partial class mainPanel
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainPanel));
            pnlFooter = new Panel();
            label1 = new Label();
            btnFormFronecedores = new Button();
            btnFormFuncionários = new Button();
            btnFormProdutos = new Button();
            btnEstadoEnc = new Button();
            btnLogout = new Button();
            lblWelcome = new Label();
            txtAccount = new TextBox();
            pnlHeader = new Panel();
            lblTitle = new Label();
            btnMinimize = new Button();
            btnMaximize = new Button();
            btnClose = new Button();
            btnFormClientes = new Button();
            pnlFooter.SuspendLayout();
            pnlHeader.SuspendLayout();
            SuspendLayout();
            // 
            // pnlFooter
            // 
            pnlFooter.BackColor = Color.FromArgb(33, 42, 62);
            pnlFooter.Controls.Add(label1);
            pnlFooter.Dock = DockStyle.Bottom;
            pnlFooter.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            pnlFooter.Location = new Point(0, 561);
            pnlFooter.Name = "pnlFooter";
            pnlFooter.Size = new Size(1105, 40);
            pnlFooter.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.FromArgb(241, 246, 249);
            label1.Location = new Point(426, 0);
            label1.Name = "label1";
            label1.Size = new Size(249, 40);
            label1.TabIndex = 0;
            label1.Text = "Sistema de Gestão de Vendas\r\nDesenvolvido por: Gonçalo Camisão";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // btnFormFronecedores
            // 
            btnFormFronecedores.BackColor = Color.FromArgb(57, 72, 103);
            btnFormFronecedores.Cursor = Cursors.Hand;
            btnFormFronecedores.FlatAppearance.BorderColor = Color.FromArgb(32, 42, 62);
            btnFormFronecedores.FlatAppearance.BorderSize = 2;
            btnFormFronecedores.FlatStyle = FlatStyle.Flat;
            btnFormFronecedores.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnFormFronecedores.ForeColor = Color.FromArgb(241, 246, 249);
            btnFormFronecedores.Location = new Point(436, 150);
            btnFormFronecedores.Name = "btnFormFronecedores";
            btnFormFronecedores.Size = new Size(225, 137);
            btnFormFronecedores.TabIndex = 4;
            btnFormFronecedores.Text = "Formulário de Fornecedores";
            btnFormFronecedores.UseVisualStyleBackColor = false;
            btnFormFronecedores.Click += button2_Click;
            // 
            // btnFormFuncionários
            // 
            btnFormFuncionários.BackColor = Color.FromArgb(57, 72, 103);
            btnFormFuncionários.Cursor = Cursors.Hand;
            btnFormFuncionários.FlatAppearance.BorderColor = Color.FromArgb(32, 42, 62);
            btnFormFuncionários.FlatAppearance.BorderSize = 2;
            btnFormFuncionários.FlatStyle = FlatStyle.Flat;
            btnFormFuncionários.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnFormFuncionários.ForeColor = Color.FromArgb(241, 246, 249);
            btnFormFuncionários.Location = new Point(307, 316);
            btnFormFuncionários.Name = "btnFormFuncionários";
            btnFormFuncionários.Size = new Size(225, 137);
            btnFormFuncionários.TabIndex = 5;
            btnFormFuncionários.Text = "Formulário de Funcionários";
            btnFormFuncionários.UseVisualStyleBackColor = false;
            btnFormFuncionários.Click += button3_Click;
            // 
            // btnFormProdutos
            // 
            btnFormProdutos.BackColor = Color.FromArgb(57, 72, 103);
            btnFormProdutos.Cursor = Cursors.Hand;
            btnFormProdutos.FlatAppearance.BorderColor = Color.FromArgb(32, 42, 62);
            btnFormProdutos.FlatAppearance.BorderSize = 2;
            btnFormProdutos.FlatStyle = FlatStyle.Flat;
            btnFormProdutos.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnFormProdutos.ForeColor = Color.FromArgb(241, 246, 249);
            btnFormProdutos.Location = new Point(687, 150);
            btnFormProdutos.Name = "btnFormProdutos";
            btnFormProdutos.Size = new Size(225, 137);
            btnFormProdutos.TabIndex = 6;
            btnFormProdutos.Text = "Formulário de Produtos ";
            btnFormProdutos.UseVisualStyleBackColor = false;
            btnFormProdutos.Click += button4_Click;
            // 
            // btnEstadoEnc
            // 
            btnEstadoEnc.BackColor = Color.FromArgb(57, 72, 103);
            btnEstadoEnc.Cursor = Cursors.Hand;
            btnEstadoEnc.FlatAppearance.BorderColor = Color.FromArgb(32, 42, 62);
            btnEstadoEnc.FlatAppearance.BorderSize = 2;
            btnEstadoEnc.FlatStyle = FlatStyle.Flat;
            btnEstadoEnc.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnEstadoEnc.ForeColor = Color.FromArgb(241, 246, 249);
            btnEstadoEnc.Location = new Point(557, 316);
            btnEstadoEnc.Name = "btnEstadoEnc";
            btnEstadoEnc.Size = new Size(225, 137);
            btnEstadoEnc.TabIndex = 8;
            btnEstadoEnc.Text = "Encomendas";
            btnEstadoEnc.UseVisualStyleBackColor = false;
            btnEstadoEnc.Click += btnEstadoEnc_Click;
            // 
            // btnLogout
            // 
            btnLogout.BackColor = Color.FromArgb(241, 246, 249);
            btnLogout.Cursor = Cursors.Hand;
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.FlatStyle = FlatStyle.Flat;
            btnLogout.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            btnLogout.ForeColor = Color.FromArgb(33, 42, 62);
            btnLogout.Image = (Image)resources.GetObject("btnLogout.Image");
            btnLogout.ImageAlign = ContentAlignment.MiddleRight;
            btnLogout.Location = new Point(996, 504);
            btnLogout.Name = "btnLogout";
            btnLogout.Size = new Size(93, 43);
            btnLogout.TabIndex = 9;
            btnLogout.Text = "Sair";
            btnLogout.TextAlign = ContentAlignment.MiddleLeft;
            btnLogout.UseVisualStyleBackColor = false;
            btnLogout.Click += btnLogout_Click;
            // 
            // lblWelcome
            // 
            lblWelcome.AutoSize = true;
            lblWelcome.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblWelcome.ForeColor = Color.FromArgb(33, 42, 62);
            lblWelcome.Location = new Point(18, 57);
            lblWelcome.Name = "lblWelcome";
            lblWelcome.Size = new Size(117, 28);
            lblWelcome.TabIndex = 11;
            lblWelcome.Text = "Bem-vindo,";
            // 
            // txtAccount
            // 
            txtAccount.BackColor = Color.FromArgb(241, 246, 249);
            txtAccount.BorderStyle = BorderStyle.None;
            txtAccount.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point);
            txtAccount.ForeColor = Color.FromArgb(33, 42, 62);
            txtAccount.Location = new Point(135, 57);
            txtAccount.Name = "txtAccount";
            txtAccount.ReadOnly = true;
            txtAccount.Size = new Size(249, 27);
            txtAccount.TabIndex = 12;
            txtAccount.TextChanged += txtAccount_TextChanged;
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.FromArgb(33, 42, 62);
            pnlHeader.Controls.Add(lblTitle);
            pnlHeader.Controls.Add(btnMinimize);
            pnlHeader.Controls.Add(btnMaximize);
            pnlHeader.Controls.Add(btnClose);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(1105, 40);
            pnlHeader.TabIndex = 13;
            pnlHeader.MouseDown += pnlHeader_MouseDown;
            pnlHeader.MouseMove += pnlHeader_MouseMove;
            pnlHeader.MouseUp += pnlHeader_MouseUp;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblTitle.ForeColor = Color.FromArgb(241, 246, 249);
            lblTitle.Location = new Point(10, 6);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(250, 28);
            lblTitle.TabIndex = 17;
            lblTitle.Text = "Painel de Gestão de Vendas";
            // 
            // btnMinimize
            // 
            btnMinimize.BackColor = Color.FromArgb(33, 42, 62);
            btnMinimize.Cursor = Cursors.Hand;
            btnMinimize.FlatAppearance.BorderSize = 0;
            btnMinimize.FlatStyle = FlatStyle.Flat;
            btnMinimize.Image = (Image)resources.GetObject("btnMinimize.Image");
            btnMinimize.Location = new Point(998, 6);
            btnMinimize.Name = "btnMinimize";
            btnMinimize.Size = new Size(29, 29);
            btnMinimize.TabIndex = 16;
            btnMinimize.UseVisualStyleBackColor = false;
            btnMinimize.Click += button6_Click_1;
            // 
            // btnMaximize
            // 
            btnMaximize.BackColor = Color.FromArgb(33, 42, 62);
            btnMaximize.Cursor = Cursors.Hand;
            btnMaximize.FlatAppearance.BorderSize = 0;
            btnMaximize.FlatStyle = FlatStyle.Flat;
            btnMaximize.Image = (Image)resources.GetObject("btnMaximize.Image");
            btnMaximize.Location = new Point(1033, 6);
            btnMaximize.Name = "btnMaximize";
            btnMaximize.Size = new Size(29, 29);
            btnMaximize.TabIndex = 15;
            btnMaximize.UseVisualStyleBackColor = false;
            btnMaximize.Click += btnMaximize_Click;
            // 
            // btnClose
            // 
            btnClose.BackColor = Color.FromArgb(33, 42, 62);
            btnClose.Cursor = Cursors.Hand;
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.FlatStyle = FlatStyle.Flat;
            btnClose.Image = (Image)resources.GetObject("btnClose.Image");
            btnClose.Location = new Point(1070, 6);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(29, 29);
            btnClose.TabIndex = 0;
            btnClose.UseVisualStyleBackColor = false;
            btnClose.Click += button6_Click;
            // 
            // btnFormClientes
            // 
            btnFormClientes.BackColor = Color.FromArgb(57, 72, 103);
            btnFormClientes.Cursor = Cursors.Hand;
            btnFormClientes.FlatAppearance.BorderColor = Color.FromArgb(32, 42, 62);
            btnFormClientes.FlatAppearance.BorderSize = 2;
            btnFormClientes.FlatStyle = FlatStyle.Flat;
            btnFormClientes.Font = new Font("Segoe UI Semibold", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnFormClientes.ForeColor = Color.FromArgb(241, 246, 249);
            btnFormClientes.Location = new Point(183, 150);
            btnFormClientes.Name = "btnFormClientes";
            btnFormClientes.Size = new Size(225, 137);
            btnFormClientes.TabIndex = 14;
            btnFormClientes.Text = "Formulário de Clientes";
            btnFormClientes.UseVisualStyleBackColor = false;
            btnFormClientes.Click += button1_Click_1;
            // 
            // mainPanel
            // 
            AutoScaleDimensions = new SizeF(9F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(241, 246, 249);
            ClientSize = new Size(1105, 601);
            Controls.Add(btnFormClientes);
            Controls.Add(pnlHeader);
            Controls.Add(txtAccount);
            Controls.Add(lblWelcome);
            Controls.Add(btnLogout);
            Controls.Add(btnEstadoEnc);
            Controls.Add(btnFormProdutos);
            Controls.Add(btnFormFuncionários);
            Controls.Add(btnFormFronecedores);
            Controls.Add(pnlFooter);
            Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.None;
            Name = "mainPanel";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Painel de Gestão";
            Load += Form1_Load;
            Paint += mainPanel_Paint;
            pnlFooter.ResumeLayout(false);
            pnlFooter.PerformLayout();
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Panel pnlFooter;
        private Label label1;
        private Button btnFormFronecedores;
        private Button btnFormFuncionários;
        private Button btnFormProdutos;
        private Button btnEstadoEnc;
        private Button btnLogout;
        private Label lblWelcome;
        private TextBox txtAccount;
        private Panel pnlHeader;
        private Button btnClose;
        private Button btnFormClientes;
        private Button btnMaximize;
        private Button btnMinimize;
        private Label lblTitle;
    }
}