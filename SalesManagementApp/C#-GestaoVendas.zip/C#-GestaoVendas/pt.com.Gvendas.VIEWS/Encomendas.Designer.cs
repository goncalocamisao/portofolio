﻿namespace C__GestaoVendas.pt.com.Gvendas.VIEWS
{
    partial class Encomendas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Encomendas));
            pnlHeader = new Panel();
            label1 = new Label();
            btnMinimize = new Button();
            btnMaximize = new Button();
            btnClose = new Button();
            btnReset = new Button();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            dbvEncomenda = new DataGridView();
            txtSearch = new TextBox();
            txt_estadoEnc = new ComboBox();
            txt_id = new TextBox();
            txt_quantidade_encomendada = new TextBox();
            txt_data_encomenda = new TextBox();
            txt_data_entrega = new TextBox();
            txt_data_despacho = new TextBox();
            lblSearch = new Label();
            lblProduto = new Label();
            lblDataEntrega = new Label();
            lblDataDespacho = new Label();
            lblDataEnc = new Label();
            lblQuantidadeEnc = new Label();
            lblCliente = new Label();
            lblEstado = new Label();
            lblId = new Label();
            txt_preco_unitario_produto = new TextBox();
            lblValorUnitario = new Label();
            txt_valor_total_encomenda = new TextBox();
            lblValorTotal = new Label();
            txt_produto = new ComboBox();
            txt_nome_cliente = new ComboBox();
            pnlHeader.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dbvEncomenda).BeginInit();
            SuspendLayout();
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.FromArgb(33, 42, 62);
            pnlHeader.Controls.Add(label1);
            pnlHeader.Controls.Add(btnMinimize);
            pnlHeader.Controls.Add(btnMaximize);
            pnlHeader.Controls.Add(btnClose);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(900, 40);
            pnlHeader.TabIndex = 73;
            pnlHeader.MouseDown += pnlHeader_MouseDown;
            pnlHeader.MouseMove += pnlHeader_MouseMove;
            pnlHeader.MouseUp += pnlHeader_MouseUp;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(241, 246, 249);
            label1.Location = new Point(9, 6);
            label1.Name = "label1";
            label1.Size = new Size(122, 28);
            label1.TabIndex = 20;
            label1.Text = "Encomendas";
            // 
            // btnMinimize
            // 
            btnMinimize.BackColor = Color.FromArgb(33, 42, 62);
            btnMinimize.Cursor = Cursors.Hand;
            btnMinimize.FlatAppearance.BorderSize = 0;
            btnMinimize.FlatStyle = FlatStyle.Flat;
            btnMinimize.Image = (Image)resources.GetObject("btnMinimize.Image");
            btnMinimize.Location = new Point(794, 6);
            btnMinimize.Name = "btnMinimize";
            btnMinimize.Size = new Size(29, 29);
            btnMinimize.TabIndex = 19;
            btnMinimize.UseVisualStyleBackColor = false;
            btnMinimize.Click += btnMinimize_Click;
            // 
            // btnMaximize
            // 
            btnMaximize.BackColor = Color.FromArgb(33, 42, 62);
            btnMaximize.Cursor = Cursors.Hand;
            btnMaximize.FlatAppearance.BorderSize = 0;
            btnMaximize.FlatStyle = FlatStyle.Flat;
            btnMaximize.Image = (Image)resources.GetObject("btnMaximize.Image");
            btnMaximize.Location = new Point(829, 6);
            btnMaximize.Name = "btnMaximize";
            btnMaximize.Size = new Size(29, 29);
            btnMaximize.TabIndex = 18;
            btnMaximize.UseVisualStyleBackColor = false;
            btnMaximize.Click += btnMaximize_Click;
            // 
            // btnClose
            // 
            btnClose.BackColor = Color.FromArgb(33, 42, 62);
            btnClose.Cursor = Cursors.Hand;
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.FlatStyle = FlatStyle.Flat;
            btnClose.Image = (Image)resources.GetObject("btnClose.Image");
            btnClose.Location = new Point(866, 6);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(29, 29);
            btnClose.TabIndex = 17;
            btnClose.UseVisualStyleBackColor = false;
            btnClose.Click += btnClose_Click;
            // 
            // btnReset
            // 
            btnReset.BackColor = Color.FromArgb(241, 246, 249);
            btnReset.Cursor = Cursors.Hand;
            btnReset.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            btnReset.FlatStyle = FlatStyle.Flat;
            btnReset.Font = new Font("Segoe UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
            btnReset.ForeColor = Color.FromArgb(33, 42, 62);
            btnReset.Location = new Point(3, 514);
            btnReset.Margin = new Padding(3, 4, 3, 4);
            btnReset.Name = "btnReset";
            btnReset.Size = new Size(46, 23);
            btnReset.TabIndex = 72;
            btnReset.Text = "Reset";
            btnReset.UseVisualStyleBackColor = false;
            btnReset.Click += btnReset_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.FromArgb(241, 246, 249);
            btnDelete.Cursor = Cursors.Hand;
            btnDelete.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.ForeColor = Color.FromArgb(33, 42, 62);
            btnDelete.Location = new Point(789, 501);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(94, 29);
            btnDelete.TabIndex = 71;
            btnDelete.Text = "Apagar";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(241, 246, 249);
            btnUpdate.Cursor = Cursors.Hand;
            btnUpdate.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.ForeColor = Color.FromArgb(33, 42, 62);
            btnUpdate.Location = new Point(599, 501);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 29);
            btnUpdate.TabIndex = 70;
            btnUpdate.Text = "Atualizar";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.FromArgb(241, 246, 249);
            btnAdd.Cursor = Cursors.Hand;
            btnAdd.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.ForeColor = Color.FromArgb(33, 42, 62);
            btnAdd.Location = new Point(410, 501);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(94, 29);
            btnAdd.TabIndex = 69;
            btnAdd.Text = "Adicionar";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // dbvEncomenda
            // 
            dbvEncomenda.BackgroundColor = Color.FromArgb(155, 164, 181);
            dbvEncomenda.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dbvEncomenda.GridColor = Color.FromArgb(33, 42, 62);
            dbvEncomenda.Location = new Point(410, 100);
            dbvEncomenda.Name = "dbvEncomenda";
            dbvEncomenda.RowHeadersWidth = 51;
            dbvEncomenda.RowTemplate.Height = 29;
            dbvEncomenda.Size = new Size(473, 382);
            dbvEncomenda.TabIndex = 68;
            dbvEncomenda.CellClick += dbvEncomenda_CellClick;
            // 
            // txtSearch
            // 
            txtSearch.BackColor = Color.FromArgb(241, 246, 249);
            txtSearch.ForeColor = Color.FromArgb(33, 42, 62);
            txtSearch.Location = new Point(484, 65);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(399, 27);
            txtSearch.TabIndex = 67;
            txtSearch.TextChanged += txtSearch_TextChanged;
            // 
            // txt_estadoEnc
            // 
            txt_estadoEnc.BackColor = Color.FromArgb(241, 246, 249);
            txt_estadoEnc.DropDownStyle = ComboBoxStyle.DropDownList;
            txt_estadoEnc.ForeColor = Color.FromArgb(33, 42, 62);
            txt_estadoEnc.FormattingEnabled = true;
            txt_estadoEnc.Items.AddRange(new object[] { "Em Curso", "Enviada", "Cancelada", "Finalizada" });
            txt_estadoEnc.Location = new Point(127, 135);
            txt_estadoEnc.Name = "txt_estadoEnc";
            txt_estadoEnc.Size = new Size(270, 28);
            txt_estadoEnc.TabIndex = 66;
            // 
            // txt_id
            // 
            txt_id.BackColor = Color.FromArgb(241, 246, 249);
            txt_id.ForeColor = Color.FromArgb(33, 42, 62);
            txt_id.Location = new Point(127, 100);
            txt_id.Name = "txt_id";
            txt_id.ReadOnly = true;
            txt_id.Size = new Size(270, 27);
            txt_id.TabIndex = 65;
            // 
            // txt_quantidade_encomendada
            // 
            txt_quantidade_encomendada.BackColor = Color.FromArgb(241, 246, 249);
            txt_quantidade_encomendada.ForeColor = Color.FromArgb(33, 42, 62);
            txt_quantidade_encomendada.Location = new Point(127, 253);
            txt_quantidade_encomendada.Name = "txt_quantidade_encomendada";
            txt_quantidade_encomendada.Size = new Size(270, 27);
            txt_quantidade_encomendada.TabIndex = 62;
            txt_quantidade_encomendada.TextChanged += txt_email_TextChanged;
            // 
            // txt_data_encomenda
            // 
            txt_data_encomenda.BackColor = Color.FromArgb(241, 246, 249);
            txt_data_encomenda.ForeColor = Color.FromArgb(33, 42, 62);
            txt_data_encomenda.Location = new Point(127, 308);
            txt_data_encomenda.Name = "txt_data_encomenda";
            txt_data_encomenda.Size = new Size(270, 27);
            txt_data_encomenda.TabIndex = 61;
            // 
            // txt_data_entrega
            // 
            txt_data_entrega.BackColor = Color.FromArgb(241, 246, 249);
            txt_data_entrega.ForeColor = Color.FromArgb(33, 42, 62);
            txt_data_entrega.Location = new Point(127, 385);
            txt_data_entrega.Name = "txt_data_entrega";
            txt_data_entrega.Size = new Size(270, 27);
            txt_data_entrega.TabIndex = 60;
            // 
            // txt_data_despacho
            // 
            txt_data_despacho.BackColor = Color.FromArgb(241, 246, 249);
            txt_data_despacho.ForeColor = Color.FromArgb(33, 42, 62);
            txt_data_despacho.Location = new Point(127, 350);
            txt_data_despacho.Name = "txt_data_despacho";
            txt_data_despacho.Size = new Size(270, 27);
            txt_data_despacho.TabIndex = 59;
            // 
            // lblSearch
            // 
            lblSearch.AutoSize = true;
            lblSearch.ForeColor = Color.FromArgb(33, 42, 62);
            lblSearch.Location = new Point(405, 65);
            lblSearch.Name = "lblSearch";
            lblSearch.Size = new Size(73, 20);
            lblSearch.TabIndex = 58;
            lblSearch.Text = "Pesquisar:";
            // 
            // lblProduto
            // 
            lblProduto.AutoSize = true;
            lblProduto.ForeColor = Color.FromArgb(33, 42, 62);
            lblProduto.Location = new Point(16, 170);
            lblProduto.Name = "lblProduto";
            lblProduto.Size = new Size(65, 20);
            lblProduto.TabIndex = 57;
            lblProduto.Text = "Produto:";
            // 
            // lblDataEntrega
            // 
            lblDataEntrega.AutoSize = true;
            lblDataEntrega.ForeColor = Color.FromArgb(33, 42, 62);
            lblDataEntrega.Location = new Point(16, 385);
            lblDataEntrega.Name = "lblDataEntrega";
            lblDataEntrega.Size = new Size(99, 20);
            lblDataEntrega.TabIndex = 56;
            lblDataEntrega.Text = "Data Entrega:";
            // 
            // lblDataDespacho
            // 
            lblDataDespacho.AutoSize = true;
            lblDataDespacho.ForeColor = Color.FromArgb(33, 42, 62);
            lblDataDespacho.Location = new Point(16, 350);
            lblDataDespacho.Name = "lblDataDespacho";
            lblDataDespacho.Size = new Size(114, 20);
            lblDataDespacho.TabIndex = 55;
            lblDataDespacho.Text = "Data Despacho:";
            // 
            // lblDataEnc
            // 
            lblDataEnc.AutoSize = true;
            lblDataEnc.ForeColor = Color.FromArgb(33, 42, 62);
            lblDataEnc.Location = new Point(16, 295);
            lblDataEnc.Name = "lblDataEnc";
            lblDataEnc.Size = new Size(90, 40);
            lblDataEnc.TabIndex = 54;
            lblDataEnc.Text = "Data \r\nEncomenda:";
            // 
            // lblQuantidadeEnc
            // 
            lblQuantidadeEnc.AutoSize = true;
            lblQuantidadeEnc.ForeColor = Color.FromArgb(33, 42, 62);
            lblQuantidadeEnc.Location = new Point(16, 240);
            lblQuantidadeEnc.Name = "lblQuantidadeEnc";
            lblQuantidadeEnc.Size = new Size(107, 40);
            lblQuantidadeEnc.TabIndex = 53;
            lblQuantidadeEnc.Text = "Quantidade \r\nEncomendada:";
            // 
            // lblCliente
            // 
            lblCliente.AutoSize = true;
            lblCliente.ForeColor = Color.FromArgb(33, 42, 62);
            lblCliente.Location = new Point(16, 205);
            lblCliente.Name = "lblCliente";
            lblCliente.Size = new Size(58, 20);
            lblCliente.TabIndex = 52;
            lblCliente.Text = "Cliente:";
            // 
            // lblEstado
            // 
            lblEstado.AutoSize = true;
            lblEstado.ForeColor = Color.FromArgb(33, 42, 62);
            lblEstado.Location = new Point(16, 135);
            lblEstado.Name = "lblEstado";
            lblEstado.Size = new Size(57, 20);
            lblEstado.TabIndex = 51;
            lblEstado.Text = "Estado:";
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.ForeColor = Color.FromArgb(33, 42, 62);
            lblId.Location = new Point(16, 100);
            lblId.Name = "lblId";
            lblId.Size = new Size(25, 20);
            lblId.TabIndex = 50;
            lblId.Text = "Id:";
            // 
            // txt_preco_unitario_produto
            // 
            txt_preco_unitario_produto.BackColor = Color.FromArgb(241, 246, 249);
            txt_preco_unitario_produto.ForeColor = Color.FromArgb(33, 42, 62);
            txt_preco_unitario_produto.Location = new Point(127, 420);
            txt_preco_unitario_produto.Name = "txt_preco_unitario_produto";
            txt_preco_unitario_produto.ReadOnly = true;
            txt_preco_unitario_produto.Size = new Size(270, 27);
            txt_preco_unitario_produto.TabIndex = 75;
            // 
            // lblValorUnitario
            // 
            lblValorUnitario.AutoSize = true;
            lblValorUnitario.ForeColor = Color.FromArgb(33, 42, 62);
            lblValorUnitario.Location = new Point(16, 420);
            lblValorUnitario.Name = "lblValorUnitario";
            lblValorUnitario.Size = new Size(103, 20);
            lblValorUnitario.TabIndex = 74;
            lblValorUnitario.Text = "Valor Unitário:";
            // 
            // txt_valor_total_encomenda
            // 
            txt_valor_total_encomenda.BackColor = Color.FromArgb(241, 246, 249);
            txt_valor_total_encomenda.ForeColor = Color.FromArgb(33, 42, 62);
            txt_valor_total_encomenda.Location = new Point(127, 455);
            txt_valor_total_encomenda.Name = "txt_valor_total_encomenda";
            txt_valor_total_encomenda.ReadOnly = true;
            txt_valor_total_encomenda.Size = new Size(270, 27);
            txt_valor_total_encomenda.TabIndex = 77;
            // 
            // lblValorTotal
            // 
            lblValorTotal.AutoSize = true;
            lblValorTotal.ForeColor = Color.FromArgb(33, 42, 62);
            lblValorTotal.Location = new Point(16, 455);
            lblValorTotal.Name = "lblValorTotal";
            lblValorTotal.Size = new Size(83, 20);
            lblValorTotal.TabIndex = 76;
            lblValorTotal.Text = "Valor Total:";
            // 
            // txt_produto
            // 
            txt_produto.BackColor = Color.FromArgb(241, 246, 249);
            txt_produto.DropDownStyle = ComboBoxStyle.DropDownList;
            txt_produto.ForeColor = Color.FromArgb(33, 42, 62);
            txt_produto.FormattingEnabled = true;
            txt_produto.Location = new Point(127, 170);
            txt_produto.Name = "txt_produto";
            txt_produto.Size = new Size(270, 28);
            txt_produto.TabIndex = 78;
            txt_produto.SelectedIndexChanged += txt_produto_SelectedIndexChanged;
            // 
            // txt_nome_cliente
            // 
            txt_nome_cliente.BackColor = Color.FromArgb(241, 246, 249);
            txt_nome_cliente.DropDownStyle = ComboBoxStyle.DropDownList;
            txt_nome_cliente.ForeColor = Color.FromArgb(33, 42, 62);
            txt_nome_cliente.FormattingEnabled = true;
            txt_nome_cliente.Location = new Point(127, 205);
            txt_nome_cliente.Name = "txt_nome_cliente";
            txt_nome_cliente.Size = new Size(270, 28);
            txt_nome_cliente.TabIndex = 79;
            // 
            // Encomendas
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(241, 246, 249);
            ClientSize = new Size(900, 540);
            Controls.Add(txt_nome_cliente);
            Controls.Add(txt_produto);
            Controls.Add(txt_valor_total_encomenda);
            Controls.Add(lblValorTotal);
            Controls.Add(txt_preco_unitario_produto);
            Controls.Add(lblValorUnitario);
            Controls.Add(pnlHeader);
            Controls.Add(btnReset);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(dbvEncomenda);
            Controls.Add(txtSearch);
            Controls.Add(txt_estadoEnc);
            Controls.Add(txt_id);
            Controls.Add(txt_quantidade_encomendada);
            Controls.Add(txt_data_encomenda);
            Controls.Add(txt_data_entrega);
            Controls.Add(txt_data_despacho);
            Controls.Add(lblSearch);
            Controls.Add(lblProduto);
            Controls.Add(lblDataEntrega);
            Controls.Add(lblDataDespacho);
            Controls.Add(lblDataEnc);
            Controls.Add(lblQuantidadeEnc);
            Controls.Add(lblCliente);
            Controls.Add(lblEstado);
            Controls.Add(lblId);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Encomendas";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Encomendas";
            Load += EstadoEncomendas_Load;
            Paint += Encomendas_Paint;
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dbvEncomenda).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel pnlHeader;
        private Label label1;
        private Button btnMinimize;
        private Button btnMaximize;
        private Button btnClose;
        private Button btnReset;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private DataGridView dbvEncomenda;
        private TextBox txtSearch;
        private ComboBox txt_estadoEnc;
        private TextBox txt_id;
        private TextBox txt_quantidade_encomendada;
        private TextBox txt_data_encomenda;
        private TextBox txt_data_entrega;
        private TextBox txt_data_despacho;
        private Label lblSearch;
        private Label lblProduto;
        private Label lblDataEntrega;
        private Label lblDataDespacho;
        private Label lblDataEnc;
        private Label lblQuantidadeEnc;
        private Label lblCliente;
        private Label lblEstado;
        private Label lblId;
        private TextBox txt_preco_unitario_produto;
        private Label lblValorUnitario;
        private TextBox txt_valor_total_encomenda;
        private Label lblValorTotal;
        private ComboBox txt_produto;
        private ComboBox txt_nome_cliente;
    }
}