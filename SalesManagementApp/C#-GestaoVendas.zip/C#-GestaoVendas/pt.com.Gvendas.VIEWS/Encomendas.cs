﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace C__GestaoVendas.pt.com.Gvendas.VIEWS
{
    public partial class Encomendas : Form
    {
        public Encomendas()
        {
            InitializeComponent();
        }

        private void EstadoEncomendas_Load(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=11/12gon;database=dbvendas";
            MySqlConnection connection = new MySqlConnection(connectionString);
            MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM tb_encomendas", connection);
            DataTable table = new DataTable();
            adapter.Fill(table);
            dbvEncomenda.DataSource = table;
            dbvEncomenda.ReadOnly = true;
            string query1 = "SELECT nome FROM tb_produtos";
            string query2 = "SELECT nome_cliente FROM tb_clientes";
            using (MySqlCommand command = new MySqlCommand(query1, connection))
            {
                connection.Open();
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        txt_produto.Items.Add(reader.GetString("nome"));
                    }
                }
            }
            using (MySqlCommand command2 = new MySqlCommand(query2, connection))
            {
                using (MySqlDataReader reader2 = command2.ExecuteReader())
                {
                    while (reader2.Read())
                    {
                        txt_nome_cliente.Items.Add(reader2.GetString("nome_cliente"));
                    }
                }
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=11/12gon;database=dbvendas";
            string query = "INSERT INTO tb_encomendas (estadoEnc, produto, nome_cliente, quantidade_encomendada, data_encomenda, data_despacho, data_entrega, preco_unitario_produto, valor_total_encomenda) VALUES (@value1, @value2, @value3, @value4, @value5, @value6, @value7, @value8, @value9)";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    connection.Open();
                    command.Parameters.AddWithValue("@value1", txt_estadoEnc.Text);
                    command.Parameters.AddWithValue("@value2", txt_produto.Text);
                    command.Parameters.AddWithValue("@value3", txt_nome_cliente.Text);
                    command.Parameters.AddWithValue("@value4", txt_quantidade_encomendada.Text);
                    command.Parameters.AddWithValue("@value5", txt_data_encomenda.Text);
                    command.Parameters.AddWithValue("@value6", txt_data_despacho.Text);
                    command.Parameters.AddWithValue("@value7", txt_data_entrega.Text);
                    command.Parameters.AddWithValue("@value8", txt_preco_unitario_produto.Text);
                    command.Parameters.AddWithValue("@value9", txt_valor_total_encomenda.Text);
                    try
                    {
                        int rowsAffected = command.ExecuteNonQuery();
                        MessageBox.Show("Encomenda adicionada com sucesso.");
                    }
                    catch (MySqlException ex)
                    {
                        MessageBox.Show("Erro ao adicionar encomenda.");
                    }
                }
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM tb_encomendas", connection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dbvEncomenda.DataSource = table;
                dbvEncomenda.ReadOnly = true;
            }
        }

        private void txt_email_TextChanged(object sender, EventArgs e)
        {
            if (double.TryParse(txt_quantidade_encomendada.Text, out double userInput) && double.TryParse(txt_preco_unitario_produto.Text, out double multiplier))
            {
                double result = userInput * multiplier;
                txt_valor_total_encomenda.Text = result.ToString();
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string searchTerm = txtSearch.Text.ToLower(); // convert search term to lowercase
            if (searchTerm != "")
            {
                foreach (DataGridViewRow row in dbvEncomenda.Rows)
                {
                    bool found = false;
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        if (cell.Value != null && cell.Value.ToString().ToLower().Contains(searchTerm)) // convert cell value to lowercase
                        {
                            found = true;
                            break;
                        }
                    }
                    row.Selected = found;
                }
            }
            else
            {
                // Clear any previous selection
                dbvEncomenda.ClearSelection();
            }
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnMaximize_Click(object sender, EventArgs e)
        {
            // Toggle the form's WindowState property and change the text of the button accordingly
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=11/12gon;database=dbvendas";
            string query = "UPDATE tb_encomendas SET estadoEnc = @value1, produto = @value2, nome_cliente = @value3, quantidade_encomendada = @value4, data_encomenda = @value5, data_despacho = @value6, data_entrega = @value7, preco_unitario_produto = @value8, valor_total_encomenda = @value9 WHERE id = @id";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    connection.Open();
                    command.Parameters.AddWithValue("@value1", txt_estadoEnc.Text);
                    command.Parameters.AddWithValue("@value2", txt_produto.Text);
                    command.Parameters.AddWithValue("@value3", txt_nome_cliente.Text);
                    command.Parameters.AddWithValue("@value4", txt_quantidade_encomendada.Text);
                    command.Parameters.AddWithValue("@value5", txt_data_encomenda.Text);
                    command.Parameters.AddWithValue("@value6", txt_data_despacho.Text);
                    command.Parameters.AddWithValue("@value7", txt_data_entrega.Text);
                    command.Parameters.AddWithValue("@value8", txt_preco_unitario_produto.Text);
                    command.Parameters.AddWithValue("@value9", txt_valor_total_encomenda.Text);
                    command.Parameters.AddWithValue("@id", txt_id.Text);
                    try
                    {
                        int rowsAffected = command.ExecuteNonQuery();
                        MessageBox.Show("Encomenda atualizada com sucesso.");
                    }
                    catch (MySqlException ex)
                    {
                        MessageBox.Show("Erro ao atualizar encomenda.");
                    }
                }

                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM tb_encomendas", connection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dbvEncomenda.DataSource = table;
                dbvEncomenda.ReadOnly = true;
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=11/12gon;database=dbvendas";
            string query = "DELETE FROM tb_encomendas WHERE id = @id";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    connection.Open();
                    command.Parameters.AddWithValue("@id", txt_id.Text);
                    try
                    {
                        int rowsAffected = command.ExecuteNonQuery();
                        MessageBox.Show("Encomenda removida com sucesso.");
                    }
                    catch (MySqlException ex)
                    {
                        MessageBox.Show("Erro ao remover encomenda.");
                    }
                }
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM tb_encomendas", connection);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dbvEncomenda.DataSource = table;
                dbvEncomenda.ReadOnly = true;
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txt_id.Text = "";
            txt_estadoEnc.SelectedIndex = -1;
            txt_produto.SelectedIndex = -1;
            txt_nome_cliente.SelectedIndex = -1;
            txt_quantidade_encomendada.Text = "";
            txt_data_encomenda.Text = "";
            txt_data_despacho.Text = "";
            txt_data_entrega.Text = "";
            txt_preco_unitario_produto.Text = "";
            txt_valor_total_encomenda.Text = "";
            txtSearch.Text = "";
            // Repeat the above line for each TextBox control you want to reset.
        }

        private void Encomendas_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, this.ClientRectangle, Color.Black, 1, ButtonBorderStyle.Solid, Color.Black, 1, ButtonBorderStyle.Solid, Color.Black, 1, ButtonBorderStyle.Solid, Color.Black, 1, ButtonBorderStyle.Solid);
        }

        private bool dragging = false;
        private Point startPoint = new Point(0, 0);

        private void pnlHeader_MouseDown(object sender, MouseEventArgs e)
        {
            dragging = true;
            startPoint = new Point(e.X, e.Y);
        }

        private void pnlHeader_MouseMove(object sender, MouseEventArgs e)
        {
            if (dragging)
            {
                Point p = PointToScreen(e.Location);
                Location = new Point(p.X - startPoint.X, p.Y - startPoint.Y);
            }
        }

        private void pnlHeader_MouseUp(object sender, MouseEventArgs e)
        {
            dragging = false;
        }

        private void dbvEncomenda_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvEncomenda.Rows[e.RowIndex];
                txt_id.Text = row.Cells[0].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvEncomenda.Rows[e.RowIndex];
                txt_estadoEnc.Text = row.Cells[3].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvEncomenda.Rows[e.RowIndex];
                txt_produto.Text = row.Cells[2].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvEncomenda.Rows[e.RowIndex];
                txt_nome_cliente.Text = row.Cells[1].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvEncomenda.Rows[e.RowIndex];
                txt_quantidade_encomendada.Text = row.Cells[4].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvEncomenda.Rows[e.RowIndex];
                txt_data_encomenda.Text = row.Cells[5].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvEncomenda.Rows[e.RowIndex];
                txt_data_despacho.Text = row.Cells[6].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvEncomenda.Rows[e.RowIndex];
                txt_data_entrega.Text = row.Cells[7].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvEncomenda.Rows[e.RowIndex];
                txt_preco_unitario_produto.Text = row.Cells[8].Value.ToString();
            }

            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dbvEncomenda.Rows[e.RowIndex];
                txt_valor_total_encomenda.Text = row.Cells[9].Value.ToString();
            }
        }

        private void txt_produto_SelectedIndexChanged(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;user=root;password=11/12gon;database=dbvendas";
            if (txt_produto.SelectedItem != null)
            {
                string selectedNomeProduto = txt_produto.SelectedItem.ToString();
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    string query2 = $"SELECT preco_unitario_do_produto FROM tb_produtos WHERE nome = '{selectedNomeProduto}'";
                    using (MySqlCommand command2 = new MySqlCommand(query2, connection))
                    {
                        using (MySqlDataReader reader2 = command2.ExecuteReader())
                        {
                            if (reader2.Read())
                            {
                                string outraColunaValue = reader2.GetString("preco_unitario_do_produto");
                                txt_preco_unitario_produto.Text = outraColunaValue;
                            }
                        }
                    }
                }
            }
        }
    }
}
