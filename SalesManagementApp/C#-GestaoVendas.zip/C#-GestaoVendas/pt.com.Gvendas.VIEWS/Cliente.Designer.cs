﻿namespace C__GestaoVendas.pt.com.Gvendas.VIEWS
{
    partial class Cliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cliente));
            lblId = new Label();
            lblState = new Label();
            lblCode = new Label();
            lblEmail = new Label();
            lblPhoneNumber = new Label();
            lblAddress = new Label();
            lblDate = new Label();
            lblName = new Label();
            lblSearch = new Label();
            txt_morada = new TextBox();
            txt_dataInicio = new TextBox();
            txt_telefone = new TextBox();
            txt_email = new TextBox();
            txt_nome_cliente = new TextBox();
            txt_cod_cliente = new TextBox();
            txt_id = new TextBox();
            txt_estadoCli = new ComboBox();
            txtSearch = new TextBox();
            dbvCliente = new DataGridView();
            btnAdd = new Button();
            btnUpdate = new Button();
            btnDelete = new Button();
            mySqlConnection1 = new MySql.Data.MySqlClient.MySqlConnection();
            button1 = new Button();
            pnlHeader = new Panel();
            lblTitle = new Label();
            btnMinimize = new Button();
            btnMaximize = new Button();
            btnClose = new Button();
            ((System.ComponentModel.ISupportInitialize)dbvCliente).BeginInit();
            pnlHeader.SuspendLayout();
            SuspendLayout();
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.ForeColor = Color.FromArgb(33, 42, 62);
            lblId.Location = new Point(11, 96);
            lblId.Name = "lblId";
            lblId.Size = new Size(25, 20);
            lblId.TabIndex = 0;
            lblId.Text = "Id:";
            // 
            // lblState
            // 
            lblState.AutoSize = true;
            lblState.ForeColor = Color.FromArgb(33, 42, 62);
            lblState.Location = new Point(11, 202);
            lblState.Name = "lblState";
            lblState.Size = new Size(57, 20);
            lblState.TabIndex = 1;
            lblState.Text = "Estado:";
            // 
            // lblCode
            // 
            lblCode.AutoSize = true;
            lblCode.ForeColor = Color.FromArgb(33, 42, 62);
            lblCode.Location = new Point(11, 132);
            lblCode.Name = "lblCode";
            lblCode.Size = new Size(61, 20);
            lblCode.TabIndex = 2;
            lblCode.Text = "Código:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.ForeColor = Color.FromArgb(33, 42, 62);
            lblEmail.Location = new Point(11, 236);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(49, 20);
            lblEmail.TabIndex = 3;
            lblEmail.Text = "Email:";
            lblEmail.Click += label4_Click;
            // 
            // lblPhoneNumber
            // 
            lblPhoneNumber.AutoSize = true;
            lblPhoneNumber.ForeColor = Color.FromArgb(33, 42, 62);
            lblPhoneNumber.Location = new Point(11, 272);
            lblPhoneNumber.Name = "lblPhoneNumber";
            lblPhoneNumber.Size = new Size(69, 20);
            lblPhoneNumber.TabIndex = 4;
            lblPhoneNumber.Text = "Telefone:";
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.ForeColor = Color.FromArgb(33, 42, 62);
            lblAddress.Location = new Point(11, 307);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(64, 20);
            lblAddress.TabIndex = 5;
            lblAddress.Text = "Morada:";
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.ForeColor = Color.FromArgb(33, 42, 62);
            lblDate.Location = new Point(11, 406);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(84, 20);
            lblDate.TabIndex = 6;
            lblDate.Text = "Data Início:";
            lblDate.Click += label7_Click;
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.ForeColor = Color.FromArgb(33, 42, 62);
            lblName.Location = new Point(11, 167);
            lblName.Name = "lblName";
            lblName.Size = new Size(53, 20);
            lblName.TabIndex = 8;
            lblName.Text = "Nome:";
            // 
            // lblSearch
            // 
            lblSearch.AutoSize = true;
            lblSearch.ForeColor = Color.FromArgb(33, 42, 62);
            lblSearch.Location = new Point(378, 62);
            lblSearch.Name = "lblSearch";
            lblSearch.Size = new Size(73, 20);
            lblSearch.TabIndex = 9;
            lblSearch.Text = "Pesquisar:";
            lblSearch.Click += lblSearch_Click;
            // 
            // txt_morada
            // 
            txt_morada.BackColor = Color.FromArgb(241, 246, 249);
            txt_morada.ForeColor = Color.FromArgb(33, 42, 62);
            txt_morada.Location = new Point(102, 307);
            txt_morada.Margin = new Padding(3, 4, 3, 4);
            txt_morada.Multiline = true;
            txt_morada.Name = "txt_morada";
            txt_morada.Size = new Size(270, 80);
            txt_morada.TabIndex = 10;
            // 
            // txt_dataInicio
            // 
            txt_dataInicio.BackColor = Color.FromArgb(241, 246, 249);
            txt_dataInicio.ForeColor = Color.FromArgb(33, 42, 62);
            txt_dataInicio.Location = new Point(102, 406);
            txt_dataInicio.Margin = new Padding(3, 4, 3, 4);
            txt_dataInicio.Name = "txt_dataInicio";
            txt_dataInicio.Size = new Size(270, 27);
            txt_dataInicio.TabIndex = 11;
            // 
            // txt_telefone
            // 
            txt_telefone.BackColor = Color.FromArgb(241, 246, 249);
            txt_telefone.ForeColor = Color.FromArgb(33, 42, 62);
            txt_telefone.Location = new Point(102, 272);
            txt_telefone.Margin = new Padding(3, 4, 3, 4);
            txt_telefone.Name = "txt_telefone";
            txt_telefone.Size = new Size(270, 27);
            txt_telefone.TabIndex = 12;
            // 
            // txt_email
            // 
            txt_email.BackColor = Color.FromArgb(241, 246, 249);
            txt_email.ForeColor = Color.FromArgb(33, 42, 62);
            txt_email.Location = new Point(102, 236);
            txt_email.Margin = new Padding(3, 4, 3, 4);
            txt_email.Name = "txt_email";
            txt_email.Size = new Size(270, 27);
            txt_email.TabIndex = 13;
            // 
            // txt_nome_cliente
            // 
            txt_nome_cliente.BackColor = Color.FromArgb(241, 246, 249);
            txt_nome_cliente.ForeColor = Color.FromArgb(33, 42, 62);
            txt_nome_cliente.Location = new Point(102, 167);
            txt_nome_cliente.Margin = new Padding(3, 4, 3, 4);
            txt_nome_cliente.Name = "txt_nome_cliente";
            txt_nome_cliente.Size = new Size(270, 27);
            txt_nome_cliente.TabIndex = 15;
            // 
            // txt_cod_cliente
            // 
            txt_cod_cliente.BackColor = Color.FromArgb(241, 246, 249);
            txt_cod_cliente.ForeColor = Color.FromArgb(33, 42, 62);
            txt_cod_cliente.Location = new Point(102, 132);
            txt_cod_cliente.Margin = new Padding(3, 4, 3, 4);
            txt_cod_cliente.Name = "txt_cod_cliente";
            txt_cod_cliente.ReadOnly = true;
            txt_cod_cliente.Size = new Size(270, 27);
            txt_cod_cliente.TabIndex = 16;
            // 
            // txt_id
            // 
            txt_id.BackColor = Color.FromArgb(241, 246, 249);
            txt_id.ForeColor = Color.FromArgb(33, 42, 62);
            txt_id.Location = new Point(102, 96);
            txt_id.Margin = new Padding(3, 4, 3, 4);
            txt_id.Name = "txt_id";
            txt_id.ReadOnly = true;
            txt_id.Size = new Size(270, 27);
            txt_id.TabIndex = 17;
            // 
            // txt_estadoCli
            // 
            txt_estadoCli.BackColor = Color.FromArgb(241, 246, 249);
            txt_estadoCli.DropDownStyle = ComboBoxStyle.DropDownList;
            txt_estadoCli.ForeColor = Color.FromArgb(33, 42, 62);
            txt_estadoCli.FormattingEnabled = true;
            txt_estadoCli.Items.AddRange(new object[] { "Ativo", "Inativo" });
            txt_estadoCli.Location = new Point(102, 202);
            txt_estadoCli.Margin = new Padding(3, 4, 3, 4);
            txt_estadoCli.Name = "txt_estadoCli";
            txt_estadoCli.Size = new Size(270, 28);
            txt_estadoCli.TabIndex = 18;
            // 
            // txtSearch
            // 
            txtSearch.BackColor = Color.FromArgb(241, 246, 249);
            txtSearch.ForeColor = Color.FromArgb(33, 42, 62);
            txtSearch.Location = new Point(457, 62);
            txtSearch.Margin = new Padding(3, 4, 3, 4);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(323, 27);
            txtSearch.TabIndex = 19;
            txtSearch.TextChanged += txtSearch_TextChanged;
            // 
            // dbvCliente
            // 
            dbvCliente.BackgroundColor = Color.FromArgb(155, 164, 181);
            dbvCliente.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dbvCliente.GridColor = Color.FromArgb(33, 42, 62);
            dbvCliente.Location = new Point(383, 96);
            dbvCliente.Margin = new Padding(3, 4, 3, 4);
            dbvCliente.Name = "dbvCliente";
            dbvCliente.RowHeadersWidth = 51;
            dbvCliente.RowTemplate.Height = 29;
            dbvCliente.Size = new Size(397, 336);
            dbvCliente.TabIndex = 20;
            dbvCliente.CellClick += dbvCliente_CellClick;
            dbvCliente.CellContentClick += dbvCliente_CellContentClick;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.FromArgb(241, 246, 249);
            btnAdd.Cursor = Cursors.Hand;
            btnAdd.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.ForeColor = Color.FromArgb(33, 42, 62);
            btnAdd.Location = new Point(383, 449);
            btnAdd.Margin = new Padding(3, 4, 3, 4);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(94, 29);
            btnAdd.TabIndex = 21;
            btnAdd.Text = "Adicionar";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            btnAdd.MouseHover += btnAdd_MouseHover;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(241, 246, 249);
            btnUpdate.Cursor = Cursors.Hand;
            btnUpdate.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.ForeColor = Color.FromArgb(33, 42, 62);
            btnUpdate.Location = new Point(534, 449);
            btnUpdate.Margin = new Padding(3, 4, 3, 4);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 29);
            btnUpdate.TabIndex = 22;
            btnUpdate.Text = "Atualizar";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            btnUpdate.MouseHover += btnUpdate_MouseHover;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.FromArgb(241, 246, 249);
            btnDelete.Cursor = Cursors.Hand;
            btnDelete.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.ForeColor = Color.FromArgb(33, 42, 62);
            btnDelete.Location = new Point(686, 449);
            btnDelete.Margin = new Padding(3, 4, 3, 4);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(94, 29);
            btnDelete.TabIndex = 23;
            btnDelete.Text = "Apagar";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            btnDelete.MouseHover += btnDelete_MouseHover;
            // 
            // mySqlConnection1
            // 
            mySqlConnection1.ConnectionString = "server=localhost;user id=root;password=11/12gon;database=db_vendas";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(241, 246, 249);
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
            button1.ForeColor = Color.FromArgb(33, 42, 62);
            button1.Location = new Point(3, 463);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(46, 23);
            button1.TabIndex = 25;
            button1.Text = "Reset";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.FromArgb(33, 42, 62);
            pnlHeader.Controls.Add(lblTitle);
            pnlHeader.Controls.Add(btnMinimize);
            pnlHeader.Controls.Add(btnMaximize);
            pnlHeader.Controls.Add(btnClose);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(800, 40);
            pnlHeader.TabIndex = 26;
            pnlHeader.MouseDown += pnlHeader_MouseDown;
            pnlHeader.MouseMove += pnlHeader_MouseMove;
            pnlHeader.MouseUp += pnlHeader_MouseUp;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblTitle.ForeColor = Color.FromArgb(241, 246, 249);
            lblTitle.Location = new Point(8, 6);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(208, 28);
            lblTitle.TabIndex = 20;
            lblTitle.Text = "Formulário de Clientes";
            // 
            // btnMinimize
            // 
            btnMinimize.BackColor = Color.FromArgb(33, 42, 62);
            btnMinimize.Cursor = Cursors.Hand;
            btnMinimize.FlatAppearance.BorderSize = 0;
            btnMinimize.FlatStyle = FlatStyle.Flat;
            btnMinimize.Image = (Image)resources.GetObject("btnMinimize.Image");
            btnMinimize.Location = new Point(693, 6);
            btnMinimize.Name = "btnMinimize";
            btnMinimize.Size = new Size(29, 29);
            btnMinimize.TabIndex = 19;
            btnMinimize.UseVisualStyleBackColor = false;
            btnMinimize.Click += btnMinimize_Click;
            // 
            // btnMaximize
            // 
            btnMaximize.BackColor = Color.FromArgb(33, 42, 62);
            btnMaximize.Cursor = Cursors.Hand;
            btnMaximize.FlatAppearance.BorderSize = 0;
            btnMaximize.FlatStyle = FlatStyle.Flat;
            btnMaximize.Image = (Image)resources.GetObject("btnMaximize.Image");
            btnMaximize.Location = new Point(728, 6);
            btnMaximize.Name = "btnMaximize";
            btnMaximize.Size = new Size(29, 29);
            btnMaximize.TabIndex = 18;
            btnMaximize.UseVisualStyleBackColor = false;
            btnMaximize.Click += btnMaximize_Click;
            // 
            // btnClose
            // 
            btnClose.BackColor = Color.FromArgb(33, 42, 62);
            btnClose.Cursor = Cursors.Hand;
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.FlatStyle = FlatStyle.Flat;
            btnClose.Image = (Image)resources.GetObject("btnClose.Image");
            btnClose.Location = new Point(765, 6);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(29, 29);
            btnClose.TabIndex = 17;
            btnClose.UseVisualStyleBackColor = false;
            btnClose.Click += btnClose_Click;
            // 
            // Cliente
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(241, 246, 249);
            ClientSize = new Size(800, 489);
            Controls.Add(pnlHeader);
            Controls.Add(button1);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(dbvCliente);
            Controls.Add(txtSearch);
            Controls.Add(txt_estadoCli);
            Controls.Add(txt_id);
            Controls.Add(txt_cod_cliente);
            Controls.Add(txt_nome_cliente);
            Controls.Add(txt_email);
            Controls.Add(txt_telefone);
            Controls.Add(txt_dataInicio);
            Controls.Add(txt_morada);
            Controls.Add(lblSearch);
            Controls.Add(lblName);
            Controls.Add(lblDate);
            Controls.Add(lblAddress);
            Controls.Add(lblPhoneNumber);
            Controls.Add(lblEmail);
            Controls.Add(lblCode);
            Controls.Add(lblState);
            Controls.Add(lblId);
            Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "Cliente";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Formulário de Clientes";
            Load += Cliente_Load;
            Paint += Cliente_Paint;
            ((System.ComponentModel.ISupportInitialize)dbvCliente).EndInit();
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblId;
        private Label lblState;
        private Label lblCode;
        private Label lblEmail;
        private Label lblPhoneNumber;
        private Label lblAddress;
        private Label lblDate;
        private Label lblName;
        private Label lblSearch;
        private TextBox txt_morada;
        private TextBox txt_dataInicio;
        private TextBox txt_telefone;
        private TextBox txt_email;
        private TextBox txt_nome_cliente;
        private TextBox txt_cod_cliente;
        private TextBox txt_id;
        private ComboBox txt_estadoCli;
        private TextBox txtSearch;
        private DataGridView dbvCliente;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private MySql.Data.MySqlClient.MySqlConnection mySqlConnection1;
        private Button button1;
        private Panel pnlHeader;
        private Button btnMinimize;
        private Button btnMaximize;
        private Button btnClose;
        private Label lblTitle;
    }
}