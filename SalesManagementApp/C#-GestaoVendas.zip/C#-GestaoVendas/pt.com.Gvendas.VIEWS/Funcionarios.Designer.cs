﻿namespace C__GestaoVendas.pt.com.Gvendas.VIEWS
{
    partial class Funcionarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Funcionarios));
            txt_email = new TextBox();
            label1 = new Label();
            btnDelete = new Button();
            btnUpdate = new Button();
            btnAdd = new Button();
            dbvFuncionario = new DataGridView();
            txtSearch = new TextBox();
            txt_estadoFunc = new ComboBox();
            txt_id = new TextBox();
            txt_cod_funcionario = new TextBox();
            txt_nome_funcionario = new TextBox();
            txt_telefone = new TextBox();
            lblSearch = new Label();
            lblName = new Label();
            lblDate = new Label();
            lblEmail = new Label();
            lblCode = new Label();
            lblState = new Label();
            lblId = new Label();
            txt_morada = new TextBox();
            lblAddress = new Label();
            txt_password = new TextBox();
            label2 = new Label();
            txt_acessos_sistema_vendas = new ComboBox();
            button1 = new Button();
            pnlHeader = new Panel();
            lblTitle = new Label();
            btnMinimize = new Button();
            btnMaximize = new Button();
            btnClose = new Button();
            ((System.ComponentModel.ISupportInitialize)dbvFuncionario).BeginInit();
            pnlHeader.SuspendLayout();
            SuspendLayout();
            // 
            // txt_email
            // 
            txt_email.BackColor = Color.FromArgb(241, 246, 249);
            txt_email.ForeColor = Color.FromArgb(33, 42, 62);
            txt_email.Location = new Point(106, 221);
            txt_email.Name = "txt_email";
            txt_email.Size = new Size(270, 27);
            txt_email.TabIndex = 72;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = Color.FromArgb(33, 42, 62);
            label1.Location = new Point(16, 221);
            label1.Name = "label1";
            label1.Size = new Size(49, 20);
            label1.TabIndex = 71;
            label1.Text = "Email:";
            // 
            // btnDelete
            // 
            btnDelete.Cursor = Cursors.Hand;
            btnDelete.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            btnDelete.FlatStyle = FlatStyle.Flat;
            btnDelete.ForeColor = Color.FromArgb(33, 42, 62);
            btnDelete.Location = new Point(690, 444);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(94, 29);
            btnDelete.TabIndex = 69;
            btnDelete.Text = "Apagar";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            btnDelete.MouseLeave += btnDelete_MouseLeave;
            btnDelete.MouseHover += btnDelete_MouseHover;
            // 
            // btnUpdate
            // 
            btnUpdate.Cursor = Cursors.Hand;
            btnUpdate.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            btnUpdate.FlatStyle = FlatStyle.Flat;
            btnUpdate.ForeColor = Color.FromArgb(33, 42, 62);
            btnUpdate.Location = new Point(538, 444);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(94, 29);
            btnUpdate.TabIndex = 68;
            btnUpdate.Text = "Atualizar";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            btnUpdate.MouseLeave += btnUpdate_MouseLeave;
            btnUpdate.MouseHover += btnUpdate_MouseHover;
            // 
            // btnAdd
            // 
            btnAdd.Cursor = Cursors.Hand;
            btnAdd.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.ForeColor = Color.FromArgb(33, 42, 62);
            btnAdd.Location = new Point(387, 444);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(94, 29);
            btnAdd.TabIndex = 67;
            btnAdd.Text = "Adicionar";
            btnAdd.UseVisualStyleBackColor = true;
            btnAdd.Click += btnAdd_Click;
            btnAdd.MouseLeave += btnAdd_MouseLeave;
            btnAdd.MouseHover += btnAdd_MouseHover;
            // 
            // dbvFuncionario
            // 
            dbvFuncionario.BackgroundColor = Color.FromArgb(155, 164, 181);
            dbvFuncionario.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dbvFuncionario.GridColor = Color.FromArgb(33, 42, 62);
            dbvFuncionario.Location = new Point(387, 92);
            dbvFuncionario.Name = "dbvFuncionario";
            dbvFuncionario.RowHeadersWidth = 51;
            dbvFuncionario.RowTemplate.Height = 29;
            dbvFuncionario.Size = new Size(397, 336);
            dbvFuncionario.TabIndex = 66;
            dbvFuncionario.CellClick += dbvFuncionario_CellClick;
            dbvFuncionario.CellFormatting += dbvFuncionario_CellFormatting;
            // 
            // txtSearch
            // 
            txtSearch.BackColor = Color.FromArgb(241, 246, 249);
            txtSearch.ForeColor = Color.FromArgb(33, 42, 62);
            txtSearch.Location = new Point(461, 57);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(323, 27);
            txtSearch.TabIndex = 65;
            txtSearch.TextChanged += txtSearch_TextChanged;
            // 
            // txt_estadoFunc
            // 
            txt_estadoFunc.BackColor = Color.FromArgb(241, 246, 249);
            txt_estadoFunc.DropDownStyle = ComboBoxStyle.DropDownList;
            txt_estadoFunc.ForeColor = Color.FromArgb(33, 42, 62);
            txt_estadoFunc.FormattingEnabled = true;
            txt_estadoFunc.Items.AddRange(new object[] { "Ativo", "Inativo" });
            txt_estadoFunc.Location = new Point(106, 186);
            txt_estadoFunc.Name = "txt_estadoFunc";
            txt_estadoFunc.Size = new Size(270, 28);
            txt_estadoFunc.TabIndex = 64;
            // 
            // txt_id
            // 
            txt_id.BackColor = Color.FromArgb(241, 246, 249);
            txt_id.ForeColor = Color.FromArgb(33, 42, 62);
            txt_id.Location = new Point(106, 81);
            txt_id.Name = "txt_id";
            txt_id.ReadOnly = true;
            txt_id.Size = new Size(270, 27);
            txt_id.TabIndex = 63;
            // 
            // txt_cod_funcionario
            // 
            txt_cod_funcionario.BackColor = Color.FromArgb(241, 246, 249);
            txt_cod_funcionario.ForeColor = Color.FromArgb(33, 42, 62);
            txt_cod_funcionario.Location = new Point(106, 116);
            txt_cod_funcionario.Name = "txt_cod_funcionario";
            txt_cod_funcionario.ReadOnly = true;
            txt_cod_funcionario.Size = new Size(270, 27);
            txt_cod_funcionario.TabIndex = 62;
            // 
            // txt_nome_funcionario
            // 
            txt_nome_funcionario.BackColor = Color.FromArgb(241, 246, 249);
            txt_nome_funcionario.ForeColor = Color.FromArgb(33, 42, 62);
            txt_nome_funcionario.Location = new Point(106, 151);
            txt_nome_funcionario.Name = "txt_nome_funcionario";
            txt_nome_funcionario.Size = new Size(270, 27);
            txt_nome_funcionario.TabIndex = 61;
            // 
            // txt_telefone
            // 
            txt_telefone.BackColor = Color.FromArgb(241, 246, 249);
            txt_telefone.ForeColor = Color.FromArgb(33, 42, 62);
            txt_telefone.Location = new Point(106, 291);
            txt_telefone.Name = "txt_telefone";
            txt_telefone.Size = new Size(270, 27);
            txt_telefone.TabIndex = 60;
            // 
            // lblSearch
            // 
            lblSearch.AutoSize = true;
            lblSearch.ForeColor = Color.FromArgb(33, 42, 62);
            lblSearch.Location = new Point(382, 57);
            lblSearch.Name = "lblSearch";
            lblSearch.Size = new Size(73, 20);
            lblSearch.TabIndex = 57;
            lblSearch.Text = "Pesquisar:";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.ForeColor = Color.FromArgb(33, 42, 62);
            lblName.Location = new Point(16, 151);
            lblName.Name = "lblName";
            lblName.Size = new Size(53, 20);
            lblName.TabIndex = 56;
            lblName.Text = "Nome:";
            // 
            // lblDate
            // 
            lblDate.AutoSize = true;
            lblDate.ForeColor = Color.FromArgb(33, 42, 62);
            lblDate.Location = new Point(16, 414);
            lblDate.Name = "lblDate";
            lblDate.Size = new Size(64, 20);
            lblDate.TabIndex = 55;
            lblDate.Text = "Acessos:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.ForeColor = Color.FromArgb(33, 42, 62);
            lblEmail.Location = new Point(16, 291);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(69, 20);
            lblEmail.TabIndex = 53;
            lblEmail.Text = "Telefone:";
            // 
            // lblCode
            // 
            lblCode.AutoSize = true;
            lblCode.ForeColor = Color.FromArgb(33, 42, 62);
            lblCode.Location = new Point(16, 116);
            lblCode.Name = "lblCode";
            lblCode.Size = new Size(61, 20);
            lblCode.TabIndex = 52;
            lblCode.Text = "Código:";
            // 
            // lblState
            // 
            lblState.AutoSize = true;
            lblState.ForeColor = Color.FromArgb(33, 42, 62);
            lblState.Location = new Point(16, 186);
            lblState.Name = "lblState";
            lblState.Size = new Size(57, 20);
            lblState.TabIndex = 51;
            lblState.Text = "Estado:";
            // 
            // lblId
            // 
            lblId.AutoSize = true;
            lblId.ForeColor = Color.FromArgb(33, 42, 62);
            lblId.Location = new Point(16, 81);
            lblId.Name = "lblId";
            lblId.Size = new Size(25, 20);
            lblId.TabIndex = 50;
            lblId.Text = "Id:";
            // 
            // txt_morada
            // 
            txt_morada.BackColor = Color.FromArgb(241, 246, 249);
            txt_morada.ForeColor = Color.FromArgb(33, 42, 62);
            txt_morada.Location = new Point(106, 325);
            txt_morada.Multiline = true;
            txt_morada.Name = "txt_morada";
            txt_morada.Size = new Size(270, 81);
            txt_morada.TabIndex = 74;
            // 
            // lblAddress
            // 
            lblAddress.AutoSize = true;
            lblAddress.ForeColor = Color.FromArgb(33, 42, 62);
            lblAddress.Location = new Point(16, 325);
            lblAddress.Name = "lblAddress";
            lblAddress.Size = new Size(64, 20);
            lblAddress.TabIndex = 73;
            lblAddress.Text = "Morada:";
            // 
            // txt_password
            // 
            txt_password.BackColor = Color.FromArgb(241, 246, 249);
            txt_password.ForeColor = Color.FromArgb(33, 42, 62);
            txt_password.Location = new Point(106, 256);
            txt_password.Name = "txt_password";
            txt_password.PasswordChar = '*';
            txt_password.Size = new Size(270, 27);
            txt_password.TabIndex = 76;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = Color.FromArgb(33, 42, 62);
            label2.Location = new Point(16, 256);
            label2.Name = "label2";
            label2.Size = new Size(73, 20);
            label2.TabIndex = 75;
            label2.Text = "Password:";
            // 
            // txt_acessos_sistema_vendas
            // 
            txt_acessos_sistema_vendas.BackColor = Color.FromArgb(241, 246, 249);
            txt_acessos_sistema_vendas.DropDownStyle = ComboBoxStyle.DropDownList;
            txt_acessos_sistema_vendas.ForeColor = Color.FromArgb(33, 42, 62);
            txt_acessos_sistema_vendas.FormattingEnabled = true;
            txt_acessos_sistema_vendas.Items.AddRange(new object[] { "Nível 1", "Nível 2" });
            txt_acessos_sistema_vendas.Location = new Point(106, 414);
            txt_acessos_sistema_vendas.Name = "txt_acessos_sistema_vendas";
            txt_acessos_sistema_vendas.Size = new Size(270, 28);
            txt_acessos_sistema_vendas.TabIndex = 77;
            // 
            // button1
            // 
            button1.Cursor = Cursors.Hand;
            button1.FlatAppearance.BorderColor = Color.FromArgb(33, 42, 62);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 7F, FontStyle.Regular, GraphicsUnit.Point);
            button1.ForeColor = Color.FromArgb(33, 42, 62);
            button1.Location = new Point(2, 465);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(46, 23);
            button1.TabIndex = 78;
            button1.Text = "Reset";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // pnlHeader
            // 
            pnlHeader.BackColor = Color.FromArgb(33, 42, 62);
            pnlHeader.Controls.Add(lblTitle);
            pnlHeader.Controls.Add(btnMinimize);
            pnlHeader.Controls.Add(btnMaximize);
            pnlHeader.Controls.Add(btnClose);
            pnlHeader.Dock = DockStyle.Top;
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Name = "pnlHeader";
            pnlHeader.Size = new Size(800, 40);
            pnlHeader.TabIndex = 79;
            pnlHeader.MouseDown += pnlHeader_MouseDown;
            pnlHeader.MouseMove += pnlHeader_MouseMove;
            pnlHeader.MouseUp += pnlHeader_MouseUp;
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            lblTitle.ForeColor = Color.FromArgb(241, 246, 249);
            lblTitle.Location = new Point(8, 6);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(251, 28);
            lblTitle.TabIndex = 20;
            lblTitle.Text = "Formulário de Funcionários";
            // 
            // btnMinimize
            // 
            btnMinimize.BackColor = Color.FromArgb(33, 42, 62);
            btnMinimize.Cursor = Cursors.Hand;
            btnMinimize.FlatAppearance.BorderSize = 0;
            btnMinimize.FlatStyle = FlatStyle.Flat;
            btnMinimize.Image = (Image)resources.GetObject("btnMinimize.Image");
            btnMinimize.Location = new Point(693, 6);
            btnMinimize.Name = "btnMinimize";
            btnMinimize.Size = new Size(29, 29);
            btnMinimize.TabIndex = 19;
            btnMinimize.UseVisualStyleBackColor = false;
            btnMinimize.Click += btnMinimize_Click;
            // 
            // btnMaximize
            // 
            btnMaximize.BackColor = Color.FromArgb(33, 42, 62);
            btnMaximize.Cursor = Cursors.Hand;
            btnMaximize.FlatAppearance.BorderSize = 0;
            btnMaximize.FlatStyle = FlatStyle.Flat;
            btnMaximize.Image = (Image)resources.GetObject("btnMaximize.Image");
            btnMaximize.Location = new Point(728, 6);
            btnMaximize.Name = "btnMaximize";
            btnMaximize.Size = new Size(29, 29);
            btnMaximize.TabIndex = 18;
            btnMaximize.UseVisualStyleBackColor = false;
            btnMaximize.Click += btnMaximize_Click;
            // 
            // btnClose
            // 
            btnClose.BackColor = Color.FromArgb(33, 42, 62);
            btnClose.Cursor = Cursors.Hand;
            btnClose.FlatAppearance.BorderSize = 0;
            btnClose.FlatStyle = FlatStyle.Flat;
            btnClose.Image = (Image)resources.GetObject("btnClose.Image");
            btnClose.Location = new Point(765, 6);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(29, 29);
            btnClose.TabIndex = 17;
            btnClose.UseVisualStyleBackColor = false;
            btnClose.Click += btnClose_Click;
            // 
            // Funcionarios
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(241, 246, 249);
            ClientSize = new Size(800, 490);
            Controls.Add(pnlHeader);
            Controls.Add(button1);
            Controls.Add(txt_acessos_sistema_vendas);
            Controls.Add(txt_password);
            Controls.Add(label2);
            Controls.Add(txt_morada);
            Controls.Add(lblAddress);
            Controls.Add(txt_email);
            Controls.Add(label1);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(dbvFuncionario);
            Controls.Add(txtSearch);
            Controls.Add(txt_estadoFunc);
            Controls.Add(txt_id);
            Controls.Add(txt_cod_funcionario);
            Controls.Add(txt_nome_funcionario);
            Controls.Add(txt_telefone);
            Controls.Add(lblSearch);
            Controls.Add(lblName);
            Controls.Add(lblDate);
            Controls.Add(lblEmail);
            Controls.Add(lblCode);
            Controls.Add(lblState);
            Controls.Add(lblId);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Funcionarios";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Funcionarios";
            Load += Funcionarios_Load;
            Paint += Funcionarios_Paint;
            ((System.ComponentModel.ISupportInitialize)dbvFuncionario).EndInit();
            pnlHeader.ResumeLayout(false);
            pnlHeader.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txt_email;
        private Label label1;
        private Button btnDelete;
        private Button btnUpdate;
        private Button btnAdd;
        private DataGridView dbvFuncionario;
        private TextBox txtSearch;
        private ComboBox txt_estadoFunc;
        private TextBox txt_id;
        private TextBox txt_cod_funcionario;
        private TextBox txt_nome_funcionario;
        private TextBox txt_telefone;
        private Label lblSearch;
        private Label lblName;
        private Label lblDate;
        private Label lblEmail;
        private Label lblCode;
        private Label lblState;
        private Label lblId;
        private TextBox txt_morada;
        private Label lblAddress;
        private TextBox txt_password;
        private Label label2;
        private ComboBox txt_acessos_sistema_vendas;
        private Button button1;
        private Panel pnlHeader;
        private Label lblTitle;
        private Button btnMinimize;
        private Button btnMaximize;
        private Button btnClose;
    }
}