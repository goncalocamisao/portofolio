package com.example.cm_projetc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
