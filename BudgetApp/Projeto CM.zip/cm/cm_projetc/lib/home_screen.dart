import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'login_screen.dart';

class HomeScreen extends StatefulWidget {
  final String username;
  HomeScreen(this.username);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<Map<String, String>> _purchases = [];
  final _descriptionController = TextEditingController();
  final _priceController = TextEditingController();
  DateTime? _selectedDate;
  DateTimeRange? _dateRange;
  String _searchQuery = '';
  String _sortBy = 'date';
  String _sortOrder = 'asc';
  String? _filterCategory;
  String? _addCategory;
  final List<String> _categories = ['Renda', 'Alimentação', 'Transporte', 'Entretenimento', 'Saúde', 'Roupa', 'Outros'];

  @override
  void initState() {
    super.initState();
    _loadPurchases();
  }

  Future<void> _loadPurchases() async {
    final prefs = await SharedPreferences.getInstance();
    final savedPurchases = prefs.getStringList('${widget.username}_purchases') ?? [];
    setState(() {
      _purchases.clear();
      for (var purchase in savedPurchases) {
        final parts = purchase.split('|');
        if (parts.length == 4) {
          _purchases.add({
            'description': parts[0],
            'date': parts[1],
            'price': parts[2],
            'category': parts[3],
          });
        }
      }
    });
  }

  Future<void> _savePurchases() async {
    final prefs = await SharedPreferences.getInstance();
    final purchaseStrings = _purchases.map((p) =>
        '${p['description']}|${p['date']}|${p['price']}|${p['category']}').toList();
    await prefs.setStringList('${widget.username}_purchases', purchaseStrings);
  }

  void _addPurchase() {
    if (_descriptionController.text.isEmpty ||
        _priceController.text.isEmpty ||
        _selectedDate == null ||
        _addCategory == null) {
      return;
    }

    final newPurchase = {
      'description': _descriptionController.text,
      'date': _selectedDate!.toLocal().toString().split(' ')[0],
      'price': _priceController.text,
      'category': _addCategory!,
    };

    setState(() {
      _purchases.add(newPurchase);
    });

    _savePurchases();
    Navigator.of(context).pop();
  }

  void _showEditPurchaseBottomSheet(int index) {
    final purchase = _purchases[index];
    _descriptionController.text = purchase['description']!;
    _priceController.text = purchase['price']!;
    _selectedDate = DateTime.parse(purchase['date']!);
    _addCategory = purchase['category'];

    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'Editar Despesa',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 16),
              TextField(
                controller: _descriptionController,
                decoration: InputDecoration(labelText: 'Nome da despesa'),
              ),
              SizedBox(height: 16),
              TextField(
                controller: _priceController,
                decoration: InputDecoration(labelText: 'Preço'),
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 16),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                      _selectedDate == null
                          ? 'Nenhuma data selecionada!'
                          : 'Data: ${_selectedDate!.toLocal().toString().split(' ')[0]}',
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                  TextButton(
                    onPressed: () => _selectDate(context),
                    child: Text('Escolher data'),
                  ),
                ],
              ),
              SizedBox(height: 16),
              DropdownButton<String>(
                value: _addCategory,
                hint: Text('Escolha a categoria'),
                items: _categories.map((category) {
                  return DropdownMenuItem(
                    child: Text(category),
                    value: category,
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _addCategory = value;
                  });
                },
              ),
              SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  TextButton(
                    child: Text('Cancelar'),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                  SizedBox(width: 8),
                  ElevatedButton(
                    child: Text('Salvar'),
                    onPressed: () {
                      setState(() {
                        _purchases[index] = {
                          'description': _descriptionController.text,
                          'date': _selectedDate!.toLocal().toString().split(' ')[0],
                          'price': _priceController.text,
                          'category': _addCategory!,
                        };
                      });

                      _savePurchases();
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  void _deletePurchase(int index) {
    setState(() {
      _purchases.removeAt(index);
    });

    _savePurchases();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
      });
    }
  }

  Future<void> _selectDateRange(BuildContext context) async {
    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
      initialDateRange: _dateRange,
    );
    if (picked != null && picked != _dateRange) {
      setState(() {
        _dateRange = picked;
      });
    }
  }

  void _showAddPurchaseBottomSheet() {
    _descriptionController.clear();
    _priceController.clear();
    _selectedDate = null;
    _addCategory = null;

    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              Text(
                'Adicionar Despesa',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 16),
              TextField(
                controller: _descriptionController,
                decoration: InputDecoration(labelText: 'Nome da despesa'),
              ),
              SizedBox(height: 16),
              TextField(
                controller: _priceController,
                decoration: InputDecoration(labelText: 'Preço'),
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 16),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                      _selectedDate == null
                          ? 'Nenhuma data selecionada!'
                          : 'Data: ${_selectedDate!.toLocal().toString().split(' ')[0]}',
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                  TextButton(
                    onPressed: () => _selectDate(context),
                    child: Text('Escolher data'),
                  ),
                ],
              ),
              SizedBox(height: 16),
              DropdownButton<String>(
                value: _addCategory,
                hint: Text('Escolha a categoria'),
                items: _categories.map((category) {
                  return DropdownMenuItem(
                    child: Text(category),
                    value: category,
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    _addCategory = value;
                  });
                },
              ),
              SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: <Widget>[
                  TextButton(
                    child: Text('Cancelar'),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                  SizedBox(width: 8),
                  ElevatedButton(
                    child: Text('Adicionar'),
                    onPressed: _addPurchase,
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('name');
    await prefs.remove('password');
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => LoginScreen()),
      (route) => false,
    );
  }

  void _resetFilters() {
    setState(() {
      _searchQuery = '';
      _filterCategory = null;
      _dateRange = null;
      _sortBy = 'date';
      _sortOrder = 'asc';
    });
  }

  List<Map<String, String>> _filterAndSortPurchases() {
    List<Map<String, String>> filteredPurchases = _purchases.where((purchase) {
      final matchesSearchQuery = purchase['description']!
          .toLowerCase()
          .contains(_searchQuery.toLowerCase());

      final matchesCategory = _filterCategory == null || purchase['category'] == _filterCategory;

      final matchesDateRange = _dateRange == null ||
          (DateTime.parse(purchase['date']!).isAfter(_dateRange!.start) &&
           DateTime.parse(purchase['date']!).isBefore(_dateRange!.end));

      return matchesSearchQuery && matchesCategory && matchesDateRange;
    }).toList();

    filteredPurchases.sort((a, b) {
      if (_sortBy == 'date') {
        return _sortOrder == 'asc'
            ? DateTime.parse(a['date']!).compareTo(DateTime.parse(b['date']!))
            : DateTime.parse(b['date']!).compareTo(DateTime.parse(a['date']!));
      } else if (_sortBy == 'price') {
        return _sortOrder == 'asc'
            ? double.parse(a['price']!).compareTo(double.parse(b['price']!))
            : double.parse(b['price']!).compareTo(double.parse(a['price']!));
      }
      return 0;
    });

    return filteredPurchases;
  }

  @override
  Widget build(BuildContext context) {
    final filteredPurchases = _filterAndSortPurchases();
    final totalSpent = filteredPurchases.fold(
        0.0, (sum, item) => sum + double.parse(item['price']!));

    return Scaffold(
      appBar: AppBar(
        title: Text('Bem-vindo, ${widget.username}'),
        actions: <Widget>[
          IconButton(
            icon: Icon(Icons.exit_to_app),
            onPressed: _logout,
          ),
        ],
      ),
      body: Column(
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(8.0),
            child: Text('Total das Despesas: € ${totalSpent.toStringAsFixed(2)}',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: filteredPurchases.length,
              itemBuilder: (context, index) {
                final purchase = filteredPurchases[index];
                return ListTile(
                  title: Text(purchase['description'] ?? ''),
                  subtitle: Text('Data: ${purchase['date'] ?? ''} - Preço: €${purchase['price'] ?? ''} - Categoria: ${purchase['category'] ?? ''}'),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      IconButton(
                        icon: Icon(Icons.edit),
                        onPressed: () => _showEditPurchaseBottomSheet(index),
                      ),
                      IconButton(
                        icon: Icon(Icons.delete),
                        onPressed: () => _deletePurchase(index),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                TextField(
                  onChanged: (value) {
                    setState(() {
                      _searchQuery = value;
                    });
                  },
                  decoration: InputDecoration(
                    labelText: 'Pesquisar',
                    border: OutlineInputBorder(),
                  ),
                ),
                SizedBox(height: 10),
                Row(
                  children: <Widget>[
                    Expanded(
                      child: DropdownButton<String>(
                        value: _filterCategory,
                        hint: Text('Categoria'),
                        items: _categories.map((category) {
                          return DropdownMenuItem(
                            child: Text(category),
                            value: category,
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            _filterCategory = value;
                          });
                        },
                      ),
                    ),
                    SizedBox(width: 10),
                    IconButton(
                      icon: Icon(Icons.calendar_today),
                      onPressed: () => _selectDateRange(context),
                    ),
                    SizedBox(width: 10),
                    DropdownButton<String>(
                      value: _sortBy,
                      onChanged: (value) {
                        setState(() {
                          _sortBy = value!;
                        });
                      },
                      items: [
                        DropdownMenuItem(child: Text('Data'), value: 'date'),
                        DropdownMenuItem(child: Text('Preço'), value: 'price'),
                      ],
                    ),
                    SizedBox(width: 10),
                    IconButton(
                      icon: Icon(
                          _sortOrder == 'asc' ? Icons.arrow_upward : Icons.arrow_downward),
                      onPressed: () {
                        setState(() {
                          _sortOrder = _sortOrder == 'asc' ? 'desc' : 'asc';
                        });
                      },
                    ),
                    SizedBox(width: 10),
                    IconButton(
                      icon: Icon(Icons.refresh),
                      onPressed: _resetFilters,
                    ),
                  ],
                ),
              ],
            ),
          ),
          SizedBox(height: 10),
          FloatingActionButton(
            onPressed: _showAddPurchaseBottomSheet,
            child: Icon(Icons.add),
          ),
          SizedBox(height: 10),
        ],
      ),
    );
  }
}
